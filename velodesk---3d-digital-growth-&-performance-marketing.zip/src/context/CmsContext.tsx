import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  ServiceItem, 
  CaseStudyItem, 
  PortfolioItem, 
  BlogPostItem, 
  StatItem, 
  TestimonialItem, 
  AuditRequest, 
  SeoSettings 
} from '../types';
import { 
  INITIAL_SERVICES, 
  INITIAL_CASE_STUDIES, 
  INITIAL_PORTFOLIO, 
  INITIAL_BLOG_POSTS, 
  INITIAL_STATS, 
  INITIAL_TESTIMONIALS, 
  INITIAL_SEO 
} from '../data/velodeskData';

export type PageRoute = 'home' | 'services' | 'casestudies' | 'portfolio' | 'blog' | 'audit' | 'admin';

interface CmsContextType {
  currentRoute: PageRoute;
  setCurrentRoute: (route: PageRoute) => void;
  selectedService: ServiceItem | null;
  setSelectedService: (service: ServiceItem | null) => void;
  selectedCaseStudy: CaseStudyItem | null;
  setSelectedCaseStudy: (caseStudy: CaseStudyItem | null) => void;
  selectedBlog: BlogPostItem | null;
  setSelectedBlog: (blog: BlogPostItem | null) => void;
  
  // Content State
  services: ServiceItem[];
  caseStudies: CaseStudyItem[];
  portfolio: PortfolioItem[];
  blogPosts: BlogPostItem[];
  stats: StatItem[];
  testimonials: TestimonialItem[];
  seoSettings: SeoSettings;
  auditLeads: AuditRequest[];

  // Update handlers (for Admin CMS)
  updateService: (updated: ServiceItem) => void;
  addService: (newService: ServiceItem) => void;
  deleteService: (id: string) => void;
  
  updateCaseStudy: (updated: CaseStudyItem) => void;
  addCaseStudy: (newCaseStudy: CaseStudyItem) => void;
  deleteCaseStudy: (id: string) => void;

  updateBlogPost: (updated: BlogPostItem) => void;
  addBlogPost: (newPost: BlogPostItem) => void;
  deleteBlogPost: (id: string) => void;

  updateStat: (updated: StatItem) => void;
  updateSeoSettings: (settings: SeoSettings) => void;
  submitAuditRequest: (req: Omit<AuditRequest, 'id' | 'createdAt'>) => AuditRequest;
  deleteAuditLead: (id: string) => void;

  // 3D & Accessibility Settings
  threeDQuality: 'high' | 'medium' | 'low';
  setThreeDQuality: (q: 'high' | 'medium' | 'low') => void;
  reducedMotion: boolean;
  setReducedMotion: (val: boolean) => void;
  resetToDefaults: () => void;
}

const CmsContext = createContext<CmsContextType | undefined>(undefined);

export const CmsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRoute, setCurrentRoute] = useState<PageRoute>('home');
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CaseStudyItem | null>(null);
  const [selectedBlog, setSelectedBlog] = useState<BlogPostItem | null>(null);

  // Load from localStorage or defaults
  const [services, setServices] = useState<ServiceItem[]>(() => {
    const saved = localStorage.getItem('velodesk_services');
    return saved ? JSON.parse(saved) : INITIAL_SERVICES;
  });

  const [caseStudies, setCaseStudies] = useState<CaseStudyItem[]>(() => {
    const saved = localStorage.getItem('velodesk_casestudies');
    return saved ? JSON.parse(saved) : INITIAL_CASE_STUDIES;
  });

  const [portfolio, setPortfolio] = useState<PortfolioItem[]>(() => {
    const saved = localStorage.getItem('velodesk_portfolio');
    return saved ? JSON.parse(saved) : INITIAL_PORTFOLIO;
  });

  const [blogPosts, setBlogPosts] = useState<BlogPostItem[]>(() => {
    const saved = localStorage.getItem('velodesk_blogs');
    return saved ? JSON.parse(saved) : INITIAL_BLOG_POSTS;
  });

  const [stats, setStats] = useState<StatItem[]>(() => {
    const saved = localStorage.getItem('velodesk_stats');
    return saved ? JSON.parse(saved) : INITIAL_STATS;
  });

  const [testimonials] = useState<TestimonialItem[]>(INITIAL_TESTIMONIALS);

  const [seoSettings, setSeoSettings] = useState<SeoSettings>(() => {
    const saved = localStorage.getItem('velodesk_seo');
    return saved ? JSON.parse(saved) : INITIAL_SEO;
  });

  const [auditLeads, setAuditLeads] = useState<AuditRequest[]>(() => {
    const saved = localStorage.getItem('velodesk_auditleads');
    return saved ? JSON.parse(saved) : [
      {
        id: 'lead-1',
        websiteUrl: 'https://vanguardretail.com',
        companyName: 'Vanguard Retail Co',
        email: 'growth@vanguardretail.com',
        primaryGoal: 'Scale E-Commerce ROAS from 2.8x to 5.0x+',
        monthlyBudget: '$25,000 - $50,000',
        channels: ['Google Ads', 'Meta Ads', 'CRO'],
        createdAt: '2026-09-21T18:40:00Z',
        calculatedScore: {
          overall: 68,
          seo: 62,
          conversion: 58,
          paidAds: 84,
          recommendation: 'High ad spend with leaky mobile checkout. High urgency for 3D CRO.'
        }
      }
    ];
  });

  // 3D & Accessibility Settings
  const [threeDQuality, setThreeDQuality] = useState<'high' | 'medium' | 'low'>('high');
  const [reducedMotion, setReducedMotion] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('velodesk_services', JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem('velodesk_casestudies', JSON.stringify(caseStudies));
  }, [caseStudies]);

  useEffect(() => {
    localStorage.setItem('velodesk_blogs', JSON.stringify(blogPosts));
  }, [blogPosts]);

  useEffect(() => {
    localStorage.setItem('velodesk_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem('velodesk_seo', JSON.stringify(seoSettings));
    if (typeof document !== 'undefined') {
      document.title = seoSettings.siteTitle;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.setAttribute('content', seoSettings.metaDescription);
    }
  }, [seoSettings]);

  useEffect(() => {
    localStorage.setItem('velodesk_auditleads', JSON.stringify(auditLeads));
  }, [auditLeads]);

  // Apply reduced-motion class to document body
  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (reducedMotion) {
        document.body.classList.add('reduced-motion');
      } else {
        document.body.classList.remove('reduced-motion');
      }
    }
  }, [reducedMotion]);

  // Handlers
  const updateService = (updated: ServiceItem) => {
    setServices(prev => prev.map(s => s.id === updated.id ? updated : s));
  };

  const addService = (newService: ServiceItem) => {
    setServices(prev => [...prev, newService]);
  };

  const deleteService = (id: string) => {
    setServices(prev => prev.filter(s => s.id !== id));
  };

  const updateCaseStudy = (updated: CaseStudyItem) => {
    setCaseStudies(prev => prev.map(cs => cs.id === updated.id ? updated : cs));
  };

  const addCaseStudy = (newCaseStudy: CaseStudyItem) => {
    setCaseStudies(prev => [...prev, newCaseStudy]);
  };

  const deleteCaseStudy = (id: string) => {
    setCaseStudies(prev => prev.filter(cs => cs.id !== id));
  };

  const updateBlogPost = (updated: BlogPostItem) => {
    setBlogPosts(prev => prev.map(b => b.id === updated.id ? updated : b));
  };

  const addBlogPost = (newPost: BlogPostItem) => {
    setBlogPosts(prev => [...prev, newPost]);
  };

  const deleteBlogPost = (id: string) => {
    setBlogPosts(prev => prev.filter(b => b.id !== id));
  };

  const updateStat = (updated: StatItem) => {
    setStats(prev => prev.map(st => st.id === updated.id ? updated : st));
  };

  const updateSeoSettings = (newSettings: SeoSettings) => {
    setSeoSettings(newSettings);
  };

  const submitAuditRequest = (req: Omit<AuditRequest, 'id' | 'createdAt'>): AuditRequest => {
    // Generate intelligent scorecard based on user input
    const baseScore = Math.floor(Math.random() * 20) + 55; // 55-75 typical pre-audit score
    const newLead: AuditRequest = {
      ...req,
      id: `lead-${Date.now()}`,
      createdAt: new Date().toISOString(),
      calculatedScore: {
        overall: baseScore,
        seo: Math.min(95, baseScore + 6),
        conversion: Math.max(45, baseScore - 12),
        paidAds: Math.min(90, baseScore + 14),
        recommendation: `Analysis for ${req.companyName || req.websiteUrl}: Substantial conversion uplift potential (+35-80%) via 3D landing acceleration, server-side CAPI tracking, and entity SEO authority.`
      }
    };
    setAuditLeads(prev => [newLead, ...prev]);
    return newLead;
  };

  const deleteAuditLead = (id: string) => {
    setAuditLeads(prev => prev.filter(l => l.id !== id));
  };

  const resetToDefaults = () => {
    setServices(INITIAL_SERVICES);
    setCaseStudies(INITIAL_CASE_STUDIES);
    setPortfolio(INITIAL_PORTFOLIO);
    setBlogPosts(INITIAL_BLOG_POSTS);
    setStats(INITIAL_STATS);
    setSeoSettings(INITIAL_SEO);
    localStorage.removeItem('velodesk_services');
    localStorage.removeItem('velodesk_casestudies');
    localStorage.removeItem('velodesk_blogs');
    localStorage.removeItem('velodesk_stats');
    localStorage.removeItem('velodesk_seo');
  };

  return (
    <CmsContext.Provider
      value={{
        currentRoute,
        setCurrentRoute: (r) => {
          setCurrentRoute(r);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        },
        selectedService,
        setSelectedService,
        selectedCaseStudy,
        setSelectedCaseStudy,
        selectedBlog,
        setSelectedBlog,
        services,
        caseStudies,
        portfolio,
        blogPosts,
        stats,
        testimonials,
        seoSettings,
        auditLeads,
        updateService,
        addService,
        deleteService,
        updateCaseStudy,
        addCaseStudy,
        deleteCaseStudy,
        updateBlogPost,
        addBlogPost,
        deleteBlogPost,
        updateStat,
        updateSeoSettings,
        submitAuditRequest,
        deleteAuditLead,
        threeDQuality,
        setThreeDQuality,
        reducedMotion,
        setReducedMotion,
        resetToDefaults
      }}
    >
      {children}
    </CmsContext.Provider>
  );
};

export const useCms = (): CmsContextType => {
  const context = useContext(CmsContext);
  if (!context) {
    throw new Error('useCms must be used within a CmsProvider');
  }
  return context;
};

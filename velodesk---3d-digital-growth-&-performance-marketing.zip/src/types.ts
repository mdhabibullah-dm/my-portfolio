export type ThreeDTextStyle = 
  | 'extruded' 
  | 'floating' 
  | 'glass' 
  | 'metallic' 
  | 'soft-depth' 
  | 'outline-extruded' 
  | 'layered-perspective';

export type ThreeDDepth = 'subtle' | 'medium' | 'deep' | 'extreme';

export interface ServiceItem {
  id: string;
  title: string;
  slug: string;
  tagline: string;
  category: 'acquisition' | 'conversion' | 'scale' | 'intelligence';
  icon: string;
  description: string;
  metrics: string;
  deliverables: string[];
  featured: boolean;
  color: string;
}

export interface CaseStudyItem {
  id: string;
  client: string;
  industry: string;
  title: string;
  slug: string;
  heroMetric: string;
  heroLabel: string;
  overview: string;
  challenge: string;
  solution: string;
  results: {
    label: string;
    value: string;
    change: string;
  }[];
  servicesUsed: string[];
  clientQuote: {
    quote: string;
    author: string;
    role: string;
    avatar?: string;
  };
  featured: boolean;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  client: string;
  description: string;
  metrics: string;
  tags: string[];
  year: string;
  gradient: string;
}

export interface BlogPostItem {
  id: string;
  title: string;
  slug: string;
  category: string;
  readTime: string;
  publishDate: string;
  excerpt: string;
  author: {
    name: string;
    role: string;
  };
  content: string;
  tags: string[];
  tableOfContents: string[];
}

export interface StatItem {
  id: string;
  value: number;
  prefix?: string;
  suffix?: string;
  label: string;
  description: string;
  style: ThreeDTextStyle;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  impactMetric: string;
  rating: number;
}

export interface AuditRequest {
  id: string;
  websiteUrl: string;
  companyName: string;
  email: string;
  primaryGoal: string;
  monthlyBudget: string;
  channels: string[];
  createdAt: string;
  calculatedScore?: {
    overall: number;
    seo: number;
    conversion: number;
    paidAds: number;
    recommendation: string;
  };
}

export interface SeoSettings {
  siteTitle: string;
  metaDescription: string;
  ogTitle: string;
  ogDescription: string;
  canonicalUrl: string;
  keywords: string;
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { CmsProvider, useCms } from './context/CmsContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { CaseStudiesPage } from './pages/CaseStudiesPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { BlogPage } from './pages/BlogPage';
import { AuditPage } from './pages/AuditPage';
import { AdminPage } from './pages/AdminPage';
import { ArrowUp, Sparkles, ArrowUpRight } from 'lucide-react';
import { ThreeDButton } from './components/3d/ThreeDButton';

const MainAppContent: React.FC = () => {
  const { currentRoute, setCurrentRoute, seoSettings } = useCms();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentRoute]);

  // Update dynamic document title based on SEO settings
  useEffect(() => {
    const titles: Record<string, string> = {
      home: seoSettings.siteTitle,
      services: `Services | ${seoSettings.siteTitle}`,
      casestudies: `Case Studies & ROI | ${seoSettings.siteTitle}`,
      portfolio: `Portfolio & Showcases | ${seoSettings.siteTitle}`,
      blog: `Tactical Insights & GEO | ${seoSettings.siteTitle}`,
      audit: `Free 3D Growth Audit | ${seoSettings.siteTitle}`,
      admin: `Admin CMS Mission Control | ${seoSettings.siteTitle}`,
    };
    document.title = titles[currentRoute] || seoSettings.siteTitle;
  }, [currentRoute, seoSettings]);

  const renderCurrentPage = () => {
    switch (currentRoute) {
      case 'home':
        return <HomePage />;
      case 'services':
        return <ServicesPage />;
      case 'casestudies':
        return <CaseStudiesPage />;
      case 'portfolio':
        return <PortfolioPage />;
      case 'blog':
        return <BlogPage />;
      case 'audit':
        return <AuditPage />;
      case 'admin':
        return <AdminPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 selection:bg-blue-600 selection:text-white font-sans antialiased overflow-x-hidden flex flex-col justify-between">
      {/* 3D Global Navigation Header */}
      <Navbar />

      {/* Main Routed Page Content */}
      <main className="flex-grow">
        {renderCurrentPage()}
      </main>

      {/* 3D Global Footer */}
      <Footer />

      {/* Floating 3D Quick Action Floating Pill (when not on audit page) */}
      {currentRoute !== 'audit' && (
        <div className="fixed bottom-6 right-6 z-40 hidden sm:block">
          <ThreeDButton
            id="floating-audit-pill"
            variant="cyan"
            size="md"
            glow={true}
            icon={<ArrowUpRight className="w-4 h-4" />}
            onClick={() => setCurrentRoute('audit')}
            className="shadow-[0_10px_25px_rgba(0,102,255,0.4)]"
          >
            Instant 3D Audit
          </ThreeDButton>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <CmsProvider>
      <MainAppContent />
    </CmsProvider>
  );
}


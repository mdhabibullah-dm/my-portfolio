import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDHeading } from '../components/3d/ThreeDHeading';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { ThreeDCard } from '../components/3d/ThreeDCard';
import { BlogPostItem } from '../types';
import { 
  Clock, 
  User, 
  Calendar, 
  Search, 
  ArrowLeft, 
  Share2, 
  Bookmark, 
  ChevronRight,
  ListOrdered
} from 'lucide-react';

export const BlogPage: React.FC = () => {
  const { blogPosts, selectedBlog, setSelectedBlog, setCurrentRoute } = useCms();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'SEO Strategy', 'CRO & Design', 'Analytics & Attribution'];

  const filteredPosts = blogPosts.filter((post) => {
    const matchesCat = selectedCategory === 'All' || post.category === selectedCategory;
    const matchesQuery = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  // If a blog is selected, render the full reading mode with floating table of contents
  if (selectedBlog) {
    return (
      <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <button
          onClick={() => setSelectedBlog(null)}
          className="inline-flex items-center gap-2 text-xs font-bold text-blue-400 hover:text-[#00D2FF] mb-8 cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
          <span>Back to All Insights</span>
        </button>

        {/* 3D Article Header */}
        <div className="mb-8">
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mb-4">
            <span className="px-3 py-1 rounded-full font-bold uppercase tracking-wider bg-blue-600/20 text-[#00D2FF] border border-blue-500/30">
              {selectedBlog.category}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {selectedBlog.publishDate}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {selectedBlog.readTime}
            </span>
          </div>

          <div className="mb-6">
            <ThreeDHeading
              level={1}
              styleVariant="extruded"
              depth="deep"
              interactive={true}
              className="text-3xl sm:text-4xl md:text-5xl font-black leading-tight"
            >
              {selectedBlog.title}
            </ThreeDHeading>
          </div>

          {/* Author Badge */}
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center font-bold text-white shadow-md">
              {selectedBlog.author.name.charAt(0)}
            </div>
            <div>
              <div className="font-bold text-sm text-white font-heading">
                {selectedBlog.author.name}
              </div>
              <div className="text-xs text-slate-400">
                {selectedBlog.author.role}
              </div>
            </div>
          </div>
        </div>

        {/* 3D Featured Visual Header */}
        <div className="w-full h-64 sm:h-80 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 p-8 sm:p-12 mb-12 flex items-center justify-center relative overflow-hidden border border-blue-500/30 shadow-[0_20px_40px_rgba(0,0,0,0.8)]">
          <div className="text-center relative z-10 max-w-xl">
            <span className="text-[11px] font-black uppercase tracking-widest text-[#00D2FF] block mb-2">
              VeloDesk Growth Playbook
            </span>
            <div className="text-2xl sm:text-3xl font-black text-white font-heading">
              {selectedBlog.title}
            </div>
          </div>
          {/* 3D Decorative Orbs */}
          <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-blue-500/20 blur-2xl pointer-events-none" />
          <div className="absolute -bottom-12 -right-12 w-48 h-48 rounded-full bg-cyan-400/20 blur-2xl pointer-events-none" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Main Article Body - Normal, Readable, Semantic HTML */}
          <div className="lg:col-span-8">
            <article className="prose prose-invert max-w-none text-slate-300 leading-relaxed text-base sm:text-lg space-y-6">
              <div className="p-4 rounded-xl bg-blue-950/40 border-l-4 border-[#00D2FF] text-blue-200 text-sm italic">
                "{selectedBlog.excerpt}"
              </div>

              {selectedBlog.content.split('\n\n').map((paragraph, index) => {
                if (paragraph.startsWith('## ')) {
                  const headingText = paragraph.replace('## ', '');
                  return (
                    <div key={index} className="pt-6 pb-2">
                      <ThreeDHeading
                        level={2}
                        styleVariant="glass"
                        depth="medium"
                        className="text-2xl font-bold"
                      >
                        {headingText}
                      </ThreeDHeading>
                    </div>
                  );
                }
                if (paragraph.startsWith('- ')) {
                  const items = paragraph.split('\n').map(item => item.replace('- ', ''));
                  return (
                    <ul key={index} className="space-y-2 text-slate-300 my-4 list-disc pl-5">
                      {items.map((it, i) => (
                        <li key={i}>{it}</li>
                      ))}
                    </ul>
                  );
                }
                if (/^\d+\./.test(paragraph)) {
                  const items = paragraph.split('\n');
                  return (
                    <ol key={index} className="space-y-2 text-slate-300 my-4 list-decimal pl-5">
                      {items.map((it, i) => (
                        <li key={i}>{it.replace(/^\d+\.\s*/, '')}</li>
                      ))}
                    </ol>
                  );
                }
                return (
                  <p key={index} className="text-slate-300 leading-relaxed">
                    {paragraph}
                  </p>
                );
              })}
            </article>

            {/* Tags */}
            <div className="mt-12 pt-6 border-t border-slate-800 flex flex-wrap gap-2">
              {selectedBlog.tags.map((t, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-lg text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300"
                >
                  #{t}
                </span>
              ))}
            </div>
          </div>

          {/* Floating Table of Contents Sidebar */}
          <div className="lg:col-span-4">
            <div className="sticky top-28 p-6 rounded-2xl bg-[#0D1526] border border-blue-500/20 shadow-xl space-y-4">
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-slate-300">
                <ListOrdered className="w-4 h-4 text-[#00D2FF]" />
                Table of Contents
              </div>
              <ul className="space-y-2 text-xs">
                {selectedBlog.tableOfContents.map((item, idx) => (
                  <li key={idx} className="text-slate-400 hover:text-white transition-colors flex items-start gap-1.5">
                    <span className="text-[#00D2FF] font-bold">0{idx + 1}.</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-4 border-t border-slate-800">
                <div className="text-xs text-slate-400 mb-2">Want help implementing these tactics?</div>
                <ThreeDButton
                  variant="cyan"
                  size="sm"
                  className="w-full"
                  onClick={() => setCurrentRoute('audit')}
                >
                  Get a Free Strategy Audit
                </ThreeDButton>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="inline-block px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400 mb-4">
          Tactical Intelligence Hub
        </span>
        <div className="mb-4">
          <ThreeDHeading
            level={1}
            styleVariant="extruded"
            depth="extreme"
            interactive={true}
            className="text-4xl sm:text-5xl md:text-6xl font-black"
          >
            INSIGHTS
          </ThreeDHeading>
        </div>
        <ThreeDText
          as="p"
          styleVariant="soft-depth"
          depth="subtle"
          size="text-base sm:text-lg"
          className="text-slate-300 leading-relaxed"
        >
          Proprietary research, engineering breakdowns, and tactical playbooks covering Generative Engine Optimization, 3D web design psychology, and privacy-first attribution.
        </ThreeDText>
      </div>

      {/* Search and Category Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-12">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search tactical articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`
                px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer
                ${selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-[0_4px_0_#003380]'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'}
              `}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Blog Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {filteredPosts.map((post) => (
          <ThreeDCard
            key={post.id}
            depthIntensity={16}
            onClick={() => setSelectedBlog(post)}
            className="group"
          >
            <div className="flex items-center justify-between text-xs text-slate-400 mb-4">
              <span className="px-3 py-1 rounded-full font-bold uppercase tracking-wider bg-blue-600/20 text-[#00D2FF] border border-blue-500/30">
                {post.category}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {post.readTime}
              </span>
            </div>

            <div className="mb-3">
              <ThreeDText
                as="h3"
                styleVariant="layered-perspective"
                depth="medium"
                size="text-lg sm:text-xl font-bold"
                className="font-heading group-hover:text-blue-300 leading-snug"
              >
                {post.title}
              </ThreeDText>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed flex-grow line-clamp-3">
              {post.excerpt}
            </p>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
              <div>
                <div className="font-bold text-slate-200">{post.author.name}</div>
                <div className="text-[11px] text-slate-500">{post.publishDate}</div>
              </div>
              <span className="font-bold text-blue-400 group-hover:text-[#00D2FF] flex items-center gap-1">
                Read Article <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </ThreeDCard>
        ))}
      </div>
    </div>
  );
};

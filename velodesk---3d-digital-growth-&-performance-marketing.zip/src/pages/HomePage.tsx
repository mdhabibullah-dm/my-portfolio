import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDHero } from '../components/3d/ThreeDHero';
import { ThreeDSection } from '../components/3d/ThreeDSection';
import { ThreeDStat } from '../components/3d/ThreeDStat';
import { ThreeDCard } from '../components/3d/ThreeDCard';
import { ThreeDIcon } from '../components/3d/ThreeDIcon';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { PROCESS_STEPS } from '../data/velodeskData';
import { ServiceItem, CaseStudyItem } from '../types';
import { 
  ArrowUpRight, 
  CheckCircle2, 
  TrendingUp, 
  Quote, 
  Layers, 
  Sparkles,
  Calendar,
  Clock,
  ChevronRight,
  ShieldCheck,
  Star
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const { 
    services, 
    caseStudies, 
    portfolio, 
    blogPosts, 
    stats, 
    testimonials, 
    setCurrentRoute, 
    setSelectedService, 
    setSelectedCaseStudy, 
    setSelectedBlog 
  } = useCms();

  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'acquisition' | 'conversion' | 'intelligence'>('all');

  const filteredServices = activeCategoryFilter === 'all'
    ? services
    : services.filter(s => s.category === activeCategoryFilter);

  return (
    <div className="relative">
      {/* 1. EXTREME 3D HERO SECTION */}
      <ThreeDHero />

      {/* 2. 3D STATISTICS COUNTER SECTION */}
      <section className="relative z-10 -mt-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {stats.map((stat) => (
            <ThreeDStat key={stat.id} stat={stat} />
          ))}
        </div>
      </section>

      {/* 3. "WHAT WE DO" / "OUR SERVICES" 3D SECTION */}
      <ThreeDSection
        id="services-section"
        badge="Enterprise Performance Architecture"
        title="OUR SERVICES"
        subtitle="Transforming digital attention into compounding commercial growth through 10 specialized 3D acquisition, conversion, and intelligence engines."
        headingStyle="extruded"
      >
        {/* Category Filter Tabs with 3D Bevel */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
          {(['all', 'acquisition', 'conversion', 'intelligence'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategoryFilter(cat)}
              className={`
                px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer
                ${activeCategoryFilter === cat 
                  ? 'bg-blue-600 text-white shadow-[0_4px_0_#003380,0_8px_16px_rgba(0,102,255,0.4)] -translate-y-0.5' 
                  : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'}
              `}
            >
              {cat === 'all' ? 'All 10 Services' : `${cat} Engines`}
            </button>
          ))}
        </div>

        {/* 3D Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <ThreeDCard
              key={service.id}
              depthIntensity={16}
              glowColor={service.color + '40'}
              onClick={() => {
                setSelectedService(service);
                setCurrentRoute('services');
              }}
              className="group"
            >
              {/* Header with 3D Icon and Badge */}
              <div className="flex items-center justify-between mb-6">
                <ThreeDIcon
                  name={service.icon}
                  size="md"
                  color={service.color}
                  glow={true}
                />
                <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400">
                  {service.metrics}
                </span>
              </div>

              {/* Service Title with 3D Floating Effect */}
              <div className="mb-3">
                <ThreeDText
                  as="h3"
                  styleVariant="glass"
                  depth="medium"
                  interactive={false}
                  size="text-xl sm:text-2xl font-bold"
                  className="group-hover:text-blue-300 font-heading"
                >
                  {service.title}
                </ThreeDText>
              </div>

              {/* Tagline */}
              <p className="text-xs font-semibold text-blue-400/90 mb-3 tracking-wide">
                {service.tagline}
              </p>

              {/* Description */}
              <p className="text-sm text-slate-400 mb-6 leading-relaxed flex-grow">
                {service.description}
              </p>

              {/* Deliverable Checkmarks */}
              <ul className="space-y-2 mb-6 pt-4 border-t border-slate-800/80 text-xs text-slate-300">
                {service.deliverables.slice(0, 3).map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00D2FF] shrink-0" />
                    <span className="truncate">{item}</span>
                  </li>
                ))}
              </ul>

              {/* Card Footer Action */}
              <div className="mt-auto pt-2 flex items-center justify-between text-xs font-bold text-blue-400 group-hover:text-[#00D2FF]">
                <span>Explore Capabilities</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
              </div>
            </ThreeDCard>
          ))}
        </div>

        <div className="mt-14 text-center">
          <ThreeDButton
            variant="secondary"
            size="lg"
            icon={<ArrowUpRight className="w-5 h-5" />}
            onClick={() => setCurrentRoute('services')}
          >
            Explore Complete Services & Deliverables Matrix
          </ThreeDButton>
        </div>
      </ThreeDSection>

      {/* 4. "OUR PROCESS" 3D SECTION */}
      <ThreeDSection
        id="process-section"
        badge="Systematic Execution Methodology"
        title="OUR PROCESS"
        subtitle="A disciplined 4-stage growth loop engineered to systematically de-risk acquisition costs and scale commercial profit."
        headingStyle="layered-perspective"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 relative">
          {PROCESS_STEPS.map((step, idx) => (
            <div
              key={step.step}
              className="relative p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#111A2E]/80 to-[#0A101D]/90 border border-slate-800 hover:border-blue-500/50 transition-all duration-300 shadow-[0_10px_25px_rgba(0,0,0,0.6)]"
            >
              {/* Step Number in 3D Metallic style */}
              <div className="mb-4 flex items-center justify-between">
                <ThreeDText
                  as="span"
                  styleVariant="metallic"
                  depth="extreme"
                  size="text-3xl sm:text-4xl font-black"
                >
                  {step.step}
                </ThreeDText>
                <ThreeDIcon name={step.icon} size="sm" color="#00D2FF" />
              </div>

              <h3 className="text-lg font-bold text-white mb-2 font-heading">
                {step.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </ThreeDSection>

      {/* 5. "CASE STUDIES" & "FEATURED WORK" 3D SECTION */}
      <ThreeDSection
        id="casestudies-section"
        badge="Empirical Client Outcomes"
        title="CASE STUDIES"
        subtitle="Real revenue, verifiable metrics, and battle-tested growth playbooks delivered for market-defining brands."
        headingStyle="metallic"
      >
        <div className="space-y-12">
          {caseStudies.map((cs, idx) => (
            <div
              key={cs.id}
              className="p-8 sm:p-10 lg:p-12 rounded-3xl bg-gradient-to-br from-[#111A2E] via-[#0E1526] to-[#080D18] border border-blue-500/30 shadow-[0_20px_50px_rgba(0,0,0,0.8)] relative overflow-hidden"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                {/* Left: Summary & Story */}
                <div className="lg:col-span-7">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/20 text-[#00D2FF] mb-4">
                    <span>{cs.client}</span>
                    <span>•</span>
                    <span>{cs.industry}</span>
                  </div>

                  <div className="mb-4">
                    <ThreeDText
                      as="h3"
                      styleVariant="glass"
                      depth="deep"
                      size="text-2xl sm:text-3xl font-extrabold"
                      className="font-heading leading-snug"
                    >
                      {cs.title}
                    </ThreeDText>
                  </div>

                  <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6">
                    {cs.overview}
                  </p>

                  {/* Client Quote Card with 3D Depth */}
                  <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 relative mb-6">
                    <Quote className="w-5 h-5 text-blue-400 mb-2 opacity-60" />
                    <p className="text-xs sm:text-sm text-slate-300 italic mb-3">
                      "{cs.clientQuote.quote}"
                    </p>
                    <div className="text-xs font-bold text-white">
                      {cs.clientQuote.author} — <span className="text-slate-400 font-normal">{cs.clientQuote.role}</span>
                    </div>
                  </div>

                  <ThreeDButton
                    variant="primary"
                    size="md"
                    icon={<ArrowUpRight className="w-4 h-4" />}
                    onClick={() => {
                      setSelectedCaseStudy(cs);
                      setCurrentRoute('casestudies');
                    }}
                  >
                    View Full Technical Case Breakdown
                  </ThreeDButton>
                </div>

                {/* Right: 3D KPI Grid & Charts */}
                <div className="lg:col-span-5 grid grid-cols-2 gap-4">
                  {cs.results.map((res, rIdx) => (
                    <div
                      key={rIdx}
                      className="p-5 rounded-2xl bg-gradient-to-b from-[#18233C] to-[#0F172A] border border-blue-500/20 shadow-[0_8px_20px_rgba(0,0,0,0.6)]"
                    >
                      <div className="text-xs text-slate-400 font-medium mb-1">
                        {res.label}
                      </div>
                      <div className="flex items-baseline gap-1 mb-1">
                        <ThreeDText
                          as="div"
                          styleVariant="extruded"
                          depth="deep"
                          size="text-2xl sm:text-3xl font-black"
                          className="text-white"
                        >
                          {res.value}
                        </ThreeDText>
                      </div>
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>{res.change} Lift</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </ThreeDSection>

      {/* 6. "INSIGHTS" / 3D BLOG SECTION */}
      <ThreeDSection
        id="insights-section"
        badge="Intelligence & Tactical Playbooks"
        title="INSIGHTS"
        subtitle="Deep teardowns of Generative Search Optimization (GEO), 3D neuro-design, server-side attribution, and AI media buying."
        headingStyle="glass"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {blogPosts.map((post) => (
            <ThreeDCard
              key={post.id}
              depthIntensity={14}
              onClick={() => {
                setSelectedBlog(post);
                setCurrentRoute('blog');
              }}
              className="group"
            >
              {/* Category Badge & Read Time */}
              <div className="flex items-center justify-between text-xs text-slate-400 mb-4">
                <span className="px-3 py-1 rounded-full font-bold uppercase tracking-wider bg-blue-600/20 text-[#00D2FF] border border-blue-500/30">
                  {post.category}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {post.readTime}
                </span>
              </div>

              {/* Title */}
              <div className="mb-3">
                <ThreeDText
                  as="h3"
                  styleVariant="layered-perspective"
                  depth="medium"
                  size="text-lg sm:text-xl font-bold"
                  className="font-heading group-hover:text-blue-300 leading-snug"
                >
                  {post.title}
                </ThreeDText>
              </div>

              {/* Excerpt */}
              <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed flex-grow line-clamp-3">
                {post.excerpt}
              </p>

              {/* Author & Read More */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-slate-200">{post.author.name}</div>
                  <div className="text-[11px] text-slate-500">{post.publishDate}</div>
                </div>
                <span className="font-bold text-blue-400 group-hover:text-[#00D2FF] flex items-center gap-1">
                  Read Article <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </ThreeDCard>
          ))}
        </div>

        <div className="mt-12 text-center">
          <ThreeDButton
            variant="secondary"
            size="md"
            icon={<ArrowUpRight className="w-4 h-4" />}
            onClick={() => setCurrentRoute('blog')}
          >
            Read All Tactical Insights
          </ThreeDButton>
        </div>
      </ThreeDSection>

      {/* 7. CLIENT TESTIMONIALS 3D GRID */}
      <ThreeDSection
        id="testimonials-section"
        badge="Executive Endorsements"
        title="WHAT LEADERS SAY"
        subtitle="Proven impact validated by founders, CMOs, and heads of e-commerce across high-growth companies."
        headingStyle="soft-depth"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="p-6 sm:p-8 rounded-2xl bg-[#0E1526] border border-slate-800 hover:border-blue-500/40 transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.6)] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-1 text-amber-400 mb-4">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <p className="text-sm text-slate-300 italic mb-6 leading-relaxed">
                  "{t.quote}"
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm text-white font-heading">{t.author}</div>
                  <div className="text-xs text-slate-400">{t.role} • {t.company}</div>
                </div>
                <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-md border border-emerald-500/30">
                  {t.impactMetric}
                </span>
              </div>
            </div>
          ))}
        </div>
      </ThreeDSection>
    </div>
  );
};

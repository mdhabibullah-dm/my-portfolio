import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDHeading } from '../components/3d/ThreeDHeading';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { 
  Database, 
  Settings, 
  Layers, 
  FileText, 
  BarChart2, 
  Users, 
  Check, 
  Trash2, 
  RefreshCw,
  Plus,
  Globe,
  Sliders
} from 'lucide-react';

export const AdminPage: React.FC = () => {
  const { 
    services, 
    updateService, 
    caseStudies, 
    updateCaseStudy, 
    blogPosts, 
    updateBlogPost, 
    stats, 
    updateStat, 
    seoSettings, 
    updateSeoSettings, 
    auditLeads, 
    deleteAuditLead,
    resetToDefaults,
    threeDQuality,
    setThreeDQuality,
    reducedMotion,
    setReducedMotion
  } = useCms();

  const [activeTab, setActiveTab] = useState<'leads' | 'services' | 'casestudies' | 'seo' | 'stats' | 'settings'>('leads');
  const [saveNotification, setSaveNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setSaveNotification(msg);
    setTimeout(() => setSaveNotification(null), 3000);
  };

  return (
    <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-[#00D2FF] mb-2">
            <Database className="w-4 h-4" />
            <span>VeloDesk Mission Control • CMS & Database Engine</span>
          </div>
          <ThreeDHeading level={1} styleVariant="extruded" depth="deep" className="text-3xl sm:text-4xl font-black">
            ADMIN CMS DASHBOARD
          </ThreeDHeading>
        </div>

        <div className="flex items-center gap-3">
          <ThreeDButton
            variant="secondary"
            size="sm"
            icon={<RefreshCw className="w-4 h-4" />}
            onClick={() => {
              if (confirm('Reset all CMS content and leads back to default baseline?')) {
                resetToDefaults();
                showNotification('All database records reset to factory defaults.');
              }
            }}
          >
            Reset Defaults
          </ThreeDButton>
        </div>
      </div>

      {saveNotification && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4 shrink-0" />
          <span>{saveNotification}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-8 p-1.5 rounded-2xl bg-slate-900 border border-slate-800">
        {[
          { id: 'leads', label: `Audit Leads (${auditLeads.length})`, icon: Users },
          { id: 'services', label: `Services (${services.length})`, icon: Layers },
          { id: 'casestudies', label: `Case Studies (${caseStudies.length})`, icon: BarChart2 },
          { id: 'stats', label: '3D Statistics', icon: Sliders },
          { id: 'seo', label: 'SEO & Meta System', icon: Globe },
          { id: 'settings', label: '3D Engine Config', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`
                px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer
                ${isActive
                  ? 'bg-blue-600 text-white shadow-[0_4px_12px_rgba(0,102,255,0.4)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}
              `}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Audit Leads Tab */}
      {activeTab === 'leads' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white font-heading">
              Inbound Growth Audit Inquiries & Scorecards
            </h3>
            <span className="text-xs text-slate-400">
              Captured via 3D Interactive Audit tool
            </span>
          </div>

          {auditLeads.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-900/50 border border-slate-800 text-slate-400">
              No audit inquiries recorded yet. Submit a test audit from the Free Audit page!
            </div>
          ) : (
            <div className="space-y-4">
              {auditLeads.map((lead) => (
                <div
                  key={lead.id}
                  className="p-6 rounded-2xl bg-[#0D1526] border border-slate-800 hover:border-blue-500/40 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
                >
                  <div className="space-y-1.5 flex-grow">
                    <div className="flex items-center gap-3">
                      <span className="font-heading font-bold text-lg text-white">
                        {lead.companyName}
                      </span>
                      <span className="text-xs px-2.5 py-0.5 rounded bg-blue-500/20 text-[#00D2FF] font-mono">
                        {lead.websiteUrl}
                      </span>
                    </div>

                    <div className="text-xs text-slate-300">
                      <strong>Contact:</strong> {lead.email} • <strong>Budget:</strong> {lead.monthlyBudget}
                    </div>

                    <div className="text-xs text-slate-400">
                      <strong>Objective:</strong> {lead.primaryGoal}
                    </div>

                    {lead.calculatedScore && (
                      <div className="pt-2 flex items-center gap-4 text-xs font-bold">
                        <span className="text-emerald-400">Overall: {lead.calculatedScore.overall}/100</span>
                        <span className="text-blue-400">SEO: {lead.calculatedScore.seo}/100</span>
                        <span className="text-amber-400">CRO: {lead.calculatedScore.conversion}/100</span>
                        <span className="text-purple-400">Ads: {lead.calculatedScore.paidAds}/100</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => {
                        deleteAuditLead(lead.id);
                        showNotification('Lead removed from database.');
                      }}
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-rose-400 hover:border-rose-500/40 transition-colors cursor-pointer"
                      title="Delete Lead"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. Services Editor Tab */}
      {activeTab === 'services' && (
        <div className="space-y-6">
          <h3 className="text-xl font-bold text-white font-heading">
            Manage 10 Core Services & 3D Offerings
          </h3>

          <div className="grid grid-cols-1 gap-6">
            {services.map((service) => (
              <div
                key={service.id}
                className="p-6 rounded-2xl bg-[#0D1526] border border-slate-800 space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Service Title</label>
                    <input
                      type="text"
                      value={service.title}
                      onChange={(e) => updateService({ ...service, title: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Tagline</label>
                    <input
                      type="text"
                      value={service.tagline}
                      onChange={(e) => updateService({ ...service, tagline: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Highlight Metric Badge</label>
                    <input
                      type="text"
                      value={service.metrics}
                      onChange={(e) => updateService({ ...service, metrics: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Description</label>
                  <textarea
                    rows={2}
                    value={service.description}
                    onChange={(e) => updateService({ ...service, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Case Studies Tab */}
      {activeTab === 'casestudies' && (
        <div className="space-y-6">
          <h3 className="text-xl font-bold text-white font-heading">
            Manage Verified Case Studies & KPI Proof
          </h3>

          <div className="space-y-6">
            {caseStudies.map((cs) => (
              <div
                key={cs.id}
                className="p-6 rounded-2xl bg-[#0D1526] border border-slate-800 space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Client Name</label>
                    <input
                      type="text"
                      value={cs.client}
                      onChange={(e) => updateCaseStudy({ ...cs, client: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Hero Metric</label>
                    <input
                      type="text"
                      value={cs.heroMetric}
                      onChange={(e) => updateCaseStudy({ ...cs, heroMetric: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Hero Label</label>
                    <input
                      type="text"
                      value={cs.heroLabel}
                      onChange={(e) => updateCaseStudy({ ...cs, heroLabel: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Case Headline</label>
                  <input
                    type="text"
                    value={cs.title}
                    onChange={(e) => updateCaseStudy({ ...cs, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Statistics Editor */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          <h3 className="text-xl font-bold text-white font-heading">
            Live 3D Statistic Counters
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {stats.map((stat) => (
              <div key={stat.id} className="p-6 rounded-2xl bg-[#0D1526] border border-slate-800 space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Prefix</label>
                    <input
                      type="text"
                      value={stat.prefix || ''}
                      onChange={(e) => updateStat({ ...stat, prefix: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Value (Number)</label>
                    <input
                      type="number"
                      value={stat.value}
                      onChange={(e) => updateStat({ ...stat, value: Number(e.target.value) })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-1">Suffix</label>
                    <input
                      type="text"
                      value={stat.suffix || ''}
                      onChange={(e) => updateStat({ ...stat, suffix: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Label</label>
                  <input
                    type="text"
                    value={stat.label}
                    onChange={(e) => updateStat({ ...stat, label: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Description</label>
                  <input
                    type="text"
                    value={stat.description}
                    onChange={(e) => updateStat({ ...stat, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. SEO Settings Editor */}
      {activeTab === 'seo' && (
        <div className="p-8 rounded-3xl bg-[#0D1526] border border-blue-500/30 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white font-heading">
              Global SEO & Social Graph Settings
            </h3>
            <span className="text-xs text-emerald-400 font-semibold">
              Live Synchronized with DOM & Meta Tags
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 font-heading">
                Browser Title Tag (&lt;title&gt;)
              </label>
              <input
                type="text"
                value={seoSettings.siteTitle}
                onChange={(e) => updateSeoSettings({ ...seoSettings, siteTitle: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 font-heading">
                Meta Description (Search Snippet)
              </label>
              <textarea
                rows={3}
                value={seoSettings.metaDescription}
                onChange={(e) => updateSeoSettings({ ...seoSettings, metaDescription: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 font-heading">
                  OpenGraph Title (Social Share)
                </label>
                <input
                  type="text"
                  value={seoSettings.ogTitle}
                  onChange={(e) => updateSeoSettings({ ...seoSettings, ogTitle: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 font-heading">
                  Canonical URL
                </label>
                <input
                  type="text"
                  value={seoSettings.canonicalUrl}
                  onChange={(e) => updateSeoSettings({ ...seoSettings, canonicalUrl: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 font-heading">
                Keywords & Topical Entities
              </label>
              <input
                type="text"
                value={seoSettings.keywords}
                onChange={(e) => updateSeoSettings({ ...seoSettings, keywords: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="pt-4 flex justify-end">
              <ThreeDButton
                variant="cyan"
                size="md"
                onClick={() => showNotification('SEO & Meta tags updated successfully.')}
              >
                Save SEO Metadata
              </ThreeDButton>
            </div>
          </div>
        </div>
      )}

      {/* 6. 3D Engine Config Tab */}
      {activeTab === 'settings' && (
        <div className="p-8 rounded-3xl bg-[#0D1526] border border-blue-500/30 space-y-6 max-w-2xl">
          <h3 className="text-xl font-bold text-white font-heading">
            3D Graphics & Accessibility Engine Parameters
          </h3>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-white mb-2 font-heading">
                3D Visual Fidelity Profile
              </label>
              <div className="grid grid-cols-3 gap-3">
                {(['high', 'medium', 'low'] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      setThreeDQuality(q);
                      showNotification(`3D quality switched to ${q}.`);
                    }}
                    className={`
                      p-4 rounded-xl text-center font-bold uppercase tracking-wider text-xs transition-all cursor-pointer border
                      ${threeDQuality === q
                        ? 'bg-blue-600 border-blue-400 text-white shadow-lg'
                        : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'}
                    `}
                  >
                    {q} Mode
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-400 mt-2">
                Controls particle count, Three.js antialiasing, and tilt calculations.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-sm text-white">Reduced Motion Mode</div>
                <div className="text-xs text-slate-400">
                  Disables tilt transforms and heavy particle animations for accessibility
                </div>
              </div>
              <button
                onClick={() => {
                  setReducedMotion(!reducedMotion);
                  showNotification(`Reduced motion ${!reducedMotion ? 'enabled' : 'disabled'}.`);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer border ${
                  reducedMotion
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                    : 'bg-slate-900 border-slate-700 text-slate-400'
                }`}
              >
                {reducedMotion ? 'Active' : 'Inactive'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

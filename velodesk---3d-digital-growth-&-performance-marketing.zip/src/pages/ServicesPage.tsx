import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDHeading } from '../components/3d/ThreeDHeading';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { ThreeDCard } from '../components/3d/ThreeDCard';
import { ThreeDIcon } from '../components/3d/ThreeDIcon';
import { ServiceItem } from '../types';
import { 
  ArrowUpRight, 
  CheckCircle2, 
  Sparkles, 
  Calculator, 
  Layers, 
  ChevronRight,
  TrendingUp,
  X
} from 'lucide-react';

export const ServicesPage: React.FC = () => {
  const { services, selectedService, setSelectedService, setCurrentRoute } = useCms();
  const [activeTab, setActiveTab] = useState<'all' | 'acquisition' | 'conversion' | 'intelligence' | 'scale'>('all');

  // Interactive ROI Calculator State
  const [calcBudget, setCalcBudget] = useState(25000);
  const [calcCvr, setCalcCvr] = useState(2.2);

  const estimatedLiftMultiplier = 1.65; // +65% average conversion lift
  const currentRevenue = (calcBudget * 3.2); // Current estimated baseline revenue
  const projectedRevenue = currentRevenue * estimatedLiftMultiplier;
  const netAddedProfit = projectedRevenue - currentRevenue;

  const filtered = activeTab === 'all'
    ? services
    : services.filter(s => s.category === activeTab);

  return (
    <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Page Header with 3D Treatment */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="inline-block px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400 mb-4">
          Integrated Growth Ecosystem
        </span>
        <div className="mb-4">
          <ThreeDHeading
            level={1}
            styleVariant="extruded"
            depth="extreme"
            interactive={true}
            className="text-4xl sm:text-5xl md:text-6xl font-black"
          >
            OUR SERVICES
          </ThreeDHeading>
        </div>
        <ThreeDText
          as="p"
          styleVariant="soft-depth"
          depth="subtle"
          size="text-base sm:text-lg"
          className="text-slate-300 leading-relaxed"
        >
          Ten modular, battle-tested performance engines engineered to dominate search rankings, maximize ad efficiency, double conversion rates, and automate customer lifetime value.
        </ThreeDText>
      </div>

      {/* Interactive Growth Calculator Widget */}
      <div className="mb-20 p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-[#111A2E] via-[#0D1526] to-[#111A2E] border border-blue-500/40 shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 rounded-xl bg-blue-600/20 text-[#00D2FF]">
            <Calculator className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-white font-heading">
              3D Performance & Conversion ROI Estimator
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Calculate the projected revenue impact of deploying VeloDesk 3D CRO and precision acquisition models.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Sliders */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <div className="flex justify-between items-center text-sm font-bold text-slate-300 mb-2">
                <span>Monthly Paid Ad Spend</span>
                <span className="text-lg font-black text-[#00D2FF]">
                  ${calcBudget.toLocaleString()}
                </span>
              </div>
              <input
                type="range"
                min="5000"
                max="250000"
                step="5000"
                value={calcBudget}
                onChange={(e) => setCalcBudget(Number(e.target.value))}
                className="w-full accent-blue-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                <span>$5,000/mo</span>
                <span>$100,000/mo</span>
                <span>$250,000/mo</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center text-sm font-bold text-slate-300 mb-2">
                <span>Current Funnel Conversion Rate (CVR)</span>
                <span className="text-lg font-black text-blue-400">
                  {calcCvr.toFixed(1)}%
                </span>
              </div>
              <input
                type="range"
                min="0.5"
                max="8.0"
                step="0.1"
                value={calcCvr}
                onChange={(e) => setCalcCvr(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer h-2 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[11px] text-slate-500 mt-1">
                <span>0.5% (Low)</span>
                <span>2.5% (Average)</span>
                <span>8.0% (High)</span>
              </div>
            </div>
          </div>

          {/* Result Cards */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold mb-1">
                Projected Monthly Pipeline
              </div>
              <ThreeDText
                as="div"
                styleVariant="metallic"
                depth="deep"
                size="text-2xl sm:text-3xl font-black"
                className="text-white mb-1"
              >
                ${Math.round(projectedRevenue).toLocaleString()}
              </ThreeDText>
              <div className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>+65% Net Lift</span>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-gradient-to-b from-blue-950/80 to-slate-900 border border-blue-500/40">
              <div className="text-xs text-blue-300 font-semibold mb-1">
                Net Added Monthly Value
              </div>
              <ThreeDText
                as="div"
                styleVariant="extruded"
                depth="extreme"
                size="text-2xl sm:text-3xl font-black"
                className="text-[#00D2FF] mb-1"
              >
                +${Math.round(netAddedProfit).toLocaleString()}
              </ThreeDText>
              <div className="text-[11px] text-slate-400">
                Via 3D web acceleration & CAPI
              </div>
            </div>

            <div className="col-span-2 text-center pt-2">
              <ThreeDButton
                variant="cyan"
                size="md"
                className="w-full"
                icon={<ArrowUpRight className="w-4 h-4" />}
                onClick={() => setCurrentRoute('audit')}
              >
                Claim This Projected Lift with a Free Audit
              </ThreeDButton>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
        {(['all', 'acquisition', 'conversion', 'intelligence', 'scale'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`
              px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer
              ${activeTab === tab
                ? 'bg-blue-600 text-white shadow-[0_4px_0_#003380,0_8px_16px_rgba(0,102,255,0.4)] -translate-y-0.5'
                : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'}
            `}
          >
            {tab === 'all' ? 'All 10 Services' : tab}
          </button>
        ))}
      </div>

      {/* 10 Services Full Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map((service) => (
          <ThreeDCard
            key={service.id}
            depthIntensity={18}
            glowColor={service.color + '40'}
            onClick={() => setSelectedService(service)}
            className="group"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <ThreeDIcon
                name={service.icon}
                size="md"
                color={service.color}
                glow={true}
              />
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400">
                {service.metrics}
              </span>
            </div>

            {/* Title with 3D Extruded style */}
            <div className="mb-2">
              <ThreeDText
                as="h3"
                styleVariant="layered-perspective"
                depth="medium"
                size="text-xl sm:text-2xl font-bold"
                className="font-heading group-hover:text-blue-300 leading-snug"
              >
                {service.title}
              </ThreeDText>
            </div>

            {/* Tagline */}
            <p className="text-xs font-semibold text-blue-400/90 mb-3 tracking-wide">
              {service.tagline}
            </p>

            {/* Description */}
            <p className="text-sm text-slate-400 mb-6 leading-relaxed flex-grow">
              {service.description}
            </p>

            {/* Deliverables */}
            <div className="pt-4 border-t border-slate-800/80 mb-6">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Core Deliverables
              </div>
              <ul className="space-y-2 text-xs text-slate-300">
                {service.deliverables.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00D2FF] shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Action */}
            <div className="mt-auto pt-2 flex items-center justify-between text-xs font-bold text-blue-400 group-hover:text-[#00D2FF]">
              <span>View Full Blueprint</span>
              <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </div>
          </ThreeDCard>
        ))}
      </div>

      {/* Selected Service Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-2xl rounded-3xl bg-[#0E1526] border border-blue-500/40 p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.9)] max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-6 right-6 p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4 mb-6">
              <ThreeDIcon name={selectedService.icon} size="lg" color={selectedService.color} />
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#00D2FF]">
                  {selectedService.metrics}
                </span>
                <ThreeDHeading level={2} styleVariant="extruded" depth="deep" className="text-2xl sm:text-3xl font-bold">
                  {selectedService.title}
                </ThreeDHeading>
              </div>
            </div>

            <p className="text-slate-300 text-base leading-relaxed mb-6">
              {selectedService.description}
            </p>

            <div className="mb-6">
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-200 mb-3 font-heading">
                Scope & Deliverables:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedService.deliverables.map((d, i) => (
                  <div key={i} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2.5 text-xs text-slate-200 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{d}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-slate-800">
              <ThreeDButton
                variant="secondary"
                size="md"
                onClick={() => setSelectedService(null)}
              >
                Close
              </ThreeDButton>
              <ThreeDButton
                variant="cyan"
                size="md"
                icon={<ArrowUpRight className="w-4 h-4" />}
                onClick={() => {
                  setSelectedService(null);
                  setCurrentRoute('audit');
                }}
              >
                Request Audit for this Service
              </ThreeDButton>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

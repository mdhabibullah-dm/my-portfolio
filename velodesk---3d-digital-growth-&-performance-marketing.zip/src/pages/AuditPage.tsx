import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDHeading } from '../components/3d/ThreeDHeading';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { ThreeDStat } from '../components/3d/ThreeDStat';
import { 
  ArrowUpRight, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles, 
  Zap, 
  TrendingUp, 
  BarChart2,
  Lock
} from 'lucide-react';

export const AuditPage: React.FC = () => {
  const { submitAuditRequest, setCurrentRoute } = useCms();

  const [websiteUrl, setWebsiteUrl] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [primaryGoal, setPrimaryGoal] = useState('Double Landing Page CVR & Conversion Funnel');
  const [monthlyBudget, setMonthlyBudget] = useState('$25,000 - $50,000');
  const [selectedChannels, setSelectedChannels] = useState<string[]>(['Google Ads', 'SEO & GEO', 'Conversion CRO']);
  const [submittedLead, setSubmittedLead] = useState<any | null>(null);

  const channelOptions = [
    'SEO & Generative Engine Optimization',
    'Google Ads & Search PPC',
    'Meta Ads & Instagram Flywheels',
    'Conversion Rate Optimization (CRO)',
    'Server-Side Analytics & GA4/CAPI',
    'High-Performance 3D Web Development',
  ];

  const toggleChannel = (channel: string) => {
    setSelectedChannels((prev) =>
      prev.includes(channel) ? prev.filter((c) => c !== channel) : [...prev, channel]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!websiteUrl || !email) return;

    const lead = submitAuditRequest({
      websiteUrl,
      companyName: companyName || websiteUrl.replace(/^https?:\/\//, '').split('/')[0],
      email,
      primaryGoal,
      monthlyBudget,
      channels: selectedChannels,
    });

    setSubmittedLead(lead);
  };

  return (
    <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="inline-block px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400 mb-4">
          Free Diagnostic Intelligence
        </span>
        <div className="mb-4">
          <ThreeDHeading
            level={1}
            styleVariant="extruded"
            depth="extreme"
            interactive={true}
            className="text-4xl sm:text-5xl md:text-6xl font-black"
          >
            GET A FREE AUDIT
          </ThreeDHeading>
        </div>
        <ThreeDText
          as="p"
          styleVariant="soft-depth"
          depth="subtle"
          size="text-base sm:text-lg"
          className="text-slate-300 leading-relaxed"
        >
          Receive a bespoke 3D Growth Blueprint evaluating your search entity salience, Core Web Vitals, checkout friction drop-offs, and first-party attribution fidelity.
        </ThreeDText>
      </div>

      {submittedLead ? (
        /* Instant 3D Growth Scorecard */
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#111A2E] via-[#0E1528] to-[#0A101E] border border-blue-500/40 shadow-[0_25px_60px_rgba(0,0,0,0.8)] text-center relative overflow-hidden">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-[0_0_25px_rgba(16,185,129,0.5)]">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <span className="text-xs font-black uppercase tracking-wider text-emerald-400 block mb-2">
            Audit Assessment Initiated
          </span>

          <ThreeDHeading level={2} styleVariant="glass" depth="deep" className="text-3xl sm:text-4xl font-black mb-4">
            Instant Diagnostic Scorecard for {submittedLead.companyName}
          </ThreeDHeading>

          <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto mb-10 leading-relaxed">
            {submittedLead.calculatedScore.recommendation}
          </p>

          {/* Scores Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10 text-left">
            <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold mb-1">Overall Health</div>
              <ThreeDText as="div" styleVariant="extruded" depth="deep" size="text-3xl font-black text-white">
                {submittedLead.calculatedScore.overall}/100
              </ThreeDText>
              <div className="text-[11px] text-amber-400 font-bold mt-1">High Uplift Window</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold mb-1">Search & GEO</div>
              <ThreeDText as="div" styleVariant="metallic" depth="medium" size="text-3xl font-black text-white">
                {submittedLead.calculatedScore.seo}/100
              </ThreeDText>
              <div className="text-[11px] text-blue-400 font-bold mt-1">Entity schema needed</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold mb-1">Conversion (CRO)</div>
              <ThreeDText as="div" styleVariant="layered-perspective" depth="medium" size="text-3xl font-black text-[#00D2FF]">
                {submittedLead.calculatedScore.conversion}/100
              </ThreeDText>
              <div className="text-[11px] text-rose-400 font-bold mt-1">Critical funnel leaks</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold mb-1">Paid Ads Scaling</div>
              <ThreeDText as="div" styleVariant="glass" depth="medium" size="text-3xl font-black text-white">
                {submittedLead.calculatedScore.paidAds}/100
              </ThreeDText>
              <div className="text-[11px] text-emerald-400 font-bold mt-1">Ready for scale</div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <ThreeDButton
              variant="cyan"
              size="lg"
              onClick={() => setCurrentRoute('admin')}
            >
              View In Admin CMS Leads
            </ThreeDButton>
            <ThreeDButton
              variant="secondary"
              size="lg"
              onClick={() => setSubmittedLead(null)}
            >
              Submit Another Audit
            </ThreeDButton>
          </div>
        </div>
      ) : (
        /* The Audit Request Form */
        <div className="p-8 sm:p-12 rounded-3xl bg-[#0D1424] border border-blue-500/30 shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 font-heading">
                  Website URL *
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://yourcompany.com"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 font-heading">
                  Company Name
                </label>
                <input
                  type="text"
                  placeholder="Acme Corporation"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 font-heading">
                  Work Email *
                </label>
                <input
                  type="email"
                  required
                  placeholder="executive@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 font-heading">
                  Current Monthly Ad Spend
                </label>
                <select
                  value={monthlyBudget}
                  onChange={(e) => setMonthlyBudget(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500 cursor-pointer"
                >
                  <option value="Under $10,000">Under $10,000 / month</option>
                  <option value="$10,000 - $25,000">$10,000 - $25,000 / month</option>
                  <option value="$25,000 - $50,000">$25,000 - $50,000 / month</option>
                  <option value="$50,000 - $100,000">$50,000 - $100,000 / month</option>
                  <option value="$100,000+">$100,000+ / month</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 font-heading">
                Primary Growth Objective
              </label>
              <input
                type="text"
                value={primaryGoal}
                onChange={(e) => setPrimaryGoal(e.target.value)}
                placeholder="e.g. Scale ROAS from 2.5x to 5.0x, rank in Perplexity/Google AI Overviews"
                className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 font-heading">
                Focus Channels for Diagnosis (Select all that apply):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {channelOptions.map((ch) => {
                  const selected = selectedChannels.includes(ch);
                  return (
                    <button
                      type="button"
                      key={ch}
                      onClick={() => toggleChannel(ch)}
                      className={`
                        p-3 rounded-xl text-left text-xs font-semibold transition-all cursor-pointer flex items-center justify-between border
                        ${selected
                          ? 'bg-blue-600/30 border-blue-500 text-white shadow-[0_0_15px_rgba(0,102,255,0.3)]'
                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'}
                      `}
                    >
                      <span className="truncate pr-2">{ch}</span>
                      <CheckCircle2 className={`w-4 h-4 shrink-0 ${selected ? 'text-[#00D2FF]' : 'text-slate-600'}`} />
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>NDA Protected • 100% Confidential Audit Assessment</span>
              </div>

              <ThreeDButton
                type="submit"
                variant="cyan"
                size="lg"
                icon={<ArrowUpRight className="w-5 h-5" />}
              >
                Generate 3D Diagnostic Audit
              </ThreeDButton>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDHeading } from '../components/3d/ThreeDHeading';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { ThreeDCard } from '../components/3d/ThreeDCard';
import { ArrowUpRight, Sparkles, Layers, Globe, Code2 } from 'lucide-react';

export const PortfolioPage: React.FC = () => {
  const { portfolio, setCurrentRoute } = useCms();
  const [activeFilter, setActiveFilter] = useState<string>('All');

  const categories = ['All', '3D Web & Growth Engine', 'PPC & Conversion Engineering', 'AI Marketing & Scale', 'Generative SEO & Authority'];

  const filteredItems = activeFilter === 'All'
    ? portfolio
    : portfolio.filter(p => p.category === activeFilter);

  return (
    <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="inline-block px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400 mb-4">
          Spatial & Technical Showcases
        </span>
        <div className="mb-4">
          <ThreeDHeading
            level={1}
            styleVariant="extruded"
            depth="extreme"
            interactive={true}
            className="text-4xl sm:text-5xl md:text-6xl font-black"
          >
            PORTFOLIO
          </ThreeDHeading>
        </div>
        <ThreeDText
          as="p"
          styleVariant="soft-depth"
          depth="subtle"
          size="text-base sm:text-lg"
          className="text-slate-300 leading-relaxed"
        >
          High-performance 3D web applications, generative search architecture, and automated acquisition flywheels engineered for global category leaders.
        </ThreeDText>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveFilter(cat)}
            className={`
              px-4 py-2 rounded-xl text-xs font-bold tracking-wide transition-all cursor-pointer
              ${activeFilter === cat
                ? 'bg-blue-600 text-white shadow-[0_4px_0_#003380,0_8px_16px_rgba(0,102,255,0.4)] -translate-y-0.5'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'}
            `}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* 3D Physical Panels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
        {filteredItems.map((item) => (
          <ThreeDCard
            key={item.id}
            depthIntensity={20}
            glowColor="rgba(0, 102, 255, 0.35)"
            className="group min-h-[420px] flex flex-col justify-between"
          >
            {/* Visual Panel Mockup Screen */}
            <div className={`w-full h-48 rounded-xl bg-gradient-to-tr ${item.gradient} p-6 relative overflow-hidden mb-6 flex flex-col justify-between shadow-[inset_0_1px_0_rgba(255,255,255,0.2),0_8px_20px_rgba(0,0,0,0.5)]`}>
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-wider bg-black/40 text-white backdrop-blur-sm border border-white/20">
                  {item.year} Showcase
                </span>
                <span className="w-2 h-2 rounded-full bg-[#00D2FF] shadow-[0_0_8px_#00D2FF]" />
              </div>

              <div>
                <div className="text-[11px] text-blue-200 uppercase tracking-widest font-bold mb-1">
                  {item.client}
                </div>
                <div className="text-xl sm:text-2xl font-black text-white font-heading drop-shadow-md">
                  {item.title}
                </div>
              </div>

              {/* Decorative 3D Wireframe Plane */}
              <div 
                className="absolute -right-8 -bottom-8 w-40 h-40 border border-white/20 rounded-2xl transform rotate-12 group-hover:rotate-45 transition-transform duration-700 pointer-events-none"
                style={{
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.1), transparent)',
                }}
              />
            </div>

            {/* Description & Metrics */}
            <div className="flex-grow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-blue-400">
                  {item.category}
                </span>
                <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/30">
                  {item.metrics}
                </span>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                {item.description}
              </p>
            </div>

            {/* Tags & Action */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div className="flex flex-wrap gap-1.5">
                {item.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-slate-900 border border-slate-700 text-slate-400"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <ThreeDButton
                variant="cyan"
                size="sm"
                icon={<ArrowUpRight className="w-3.5 h-3.5" />}
                onClick={() => setCurrentRoute('audit')}
              >
                Inquire
              </ThreeDButton>
            </div>
          </ThreeDCard>
        ))}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { useCms } from '../context/CmsContext';
import { ThreeDHeading } from '../components/3d/ThreeDHeading';
import { ThreeDText } from '../components/3d/ThreeDText';
import { ThreeDButton } from '../components/3d/ThreeDButton';
import { ThreeDCard } from '../components/3d/ThreeDCard';
import { CaseStudyItem } from '../types';
import { 
  TrendingUp, 
  ArrowUpRight, 
  Quote, 
  CheckCircle2, 
  BarChart3, 
  Layers, 
  Target,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const CaseStudiesPage: React.FC = () => {
  const { caseStudies, selectedCaseStudy, setSelectedCaseStudy, setCurrentRoute } = useCms();
  const [activeStudy, setActiveStudy] = useState<CaseStudyItem>(selectedCaseStudy || caseStudies[0]);

  return (
    <div className="pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="inline-block px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/10 border border-blue-500/30 text-blue-400 mb-4">
          Verified Performance Records
        </span>
        <div className="mb-4">
          <ThreeDHeading
            level={1}
            styleVariant="extruded"
            depth="extreme"
            interactive={true}
            className="text-4xl sm:text-5xl md:text-6xl font-black"
          >
            CASE STUDIES
          </ThreeDHeading>
        </div>
        <ThreeDText
          as="p"
          styleVariant="soft-depth"
          depth="subtle"
          size="text-base sm:text-lg"
          className="text-slate-300 leading-relaxed"
        >
          Detailed architectural breakdowns of how VeloDesk deployed 3D conversion funnels, generative SEO, and predictive bidding to generate tens of millions in enterprise pipeline.
        </ThreeDText>
      </div>

      {/* Case Study Selector Tabs with 3D Bevel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-14">
        {caseStudies.map((cs) => {
          const isSelected = activeStudy.id === cs.id;
          return (
            <button
              key={cs.id}
              onClick={() => setActiveStudy(cs)}
              className={`
                p-6 rounded-2xl text-left transition-all duration-200 cursor-pointer relative overflow-hidden
                ${isSelected
                  ? 'bg-gradient-to-br from-blue-900/60 to-slate-900 border-2 border-blue-500 shadow-[0_10px_30px_rgba(0,102,255,0.3)] -translate-y-1'
                  : 'bg-slate-900/70 border border-slate-800 hover:border-slate-700 hover:bg-slate-900'}
              `}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  {cs.client}
                </span>
                <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  {cs.heroMetric}
                </span>
              </div>
              <h3 className="font-heading font-bold text-sm sm:text-base text-white line-clamp-2">
                {cs.title}
              </h3>
            </button>
          );
        })}
      </div>

      {/* Main Selected Case Study Deep Breakdown */}
      <div className="p-8 sm:p-12 lg:p-16 rounded-3xl bg-[#0D1424] border border-blue-500/30 shadow-[0_25px_60px_rgba(0,0,0,0.8)] relative overflow-hidden mb-16">
        {/* Background glow accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header Metadata */}
        <div className="flex flex-wrap items-center gap-3 mb-6">
          <span className="px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-600/20 text-[#00D2FF] border border-blue-500/30">
            {activeStudy.industry}
          </span>
          <span className="text-slate-400 text-xs font-medium">
            Client: <strong className="text-white">{activeStudy.client}</strong>
          </span>
          <span className="flex items-center gap-1 text-xs text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            Attribution Verified
          </span>
        </div>

        {/* Title */}
        <div className="mb-8 max-w-4xl">
          <ThreeDHeading
            level={2}
            styleVariant="glass"
            depth="deep"
            className="text-2xl sm:text-3xl md:text-4xl font-black leading-tight"
          >
            {activeStudy.title}
          </ThreeDHeading>
        </div>

        {/* 3D KPI Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {activeStudy.results.map((res, i) => (
            <div
              key={i}
              className="p-6 rounded-2xl bg-gradient-to-b from-[#16213A] to-[#0D1527] border border-blue-500/30 shadow-[0_10px_25px_rgba(0,0,0,0.6)]"
            >
              <div className="text-xs text-slate-400 font-semibold mb-1">
                {res.label}
              </div>
              <ThreeDText
                as="div"
                styleVariant="extruded"
                depth="extreme"
                size="text-2xl sm:text-3xl font-black"
                className="text-white mb-2"
              >
                {res.value}
              </ThreeDText>
              <div className="text-xs font-black text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>{res.change} Verified Lift</span>
              </div>
            </div>
          ))}
        </div>

        {/* Challenge & Solution Architecture */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-rose-400 text-xs font-black uppercase tracking-wider mb-3">
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              The Pre-VeloDesk Challenge
            </div>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {activeStudy.challenge}
            </p>
          </div>

          <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-blue-500/30">
            <div className="flex items-center gap-2 text-[#00D2FF] text-xs font-black uppercase tracking-wider mb-3">
              <span className="w-2 h-2 rounded-full bg-[#00D2FF]" />
              The VeloDesk 3D Solution Architecture
            </div>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {activeStudy.solution}
            </p>
          </div>
        </div>

        {/* Services Deployed */}
        <div className="mb-10">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3 font-heading">
            Services & Infrastructure Deployed:
          </h4>
          <div className="flex flex-wrap gap-2.5">
            {activeStudy.servicesUsed.map((s, idx) => (
              <span
                key={idx}
                className="px-3.5 py-1.5 rounded-xl bg-blue-950/60 border border-blue-500/30 text-xs font-bold text-blue-300"
              >
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Executive Quote */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-blue-950/60 border border-blue-500/30 relative">
          <Quote className="w-6 h-6 text-blue-400 mb-3 opacity-70" />
          <p className="text-base sm:text-lg text-slate-200 italic mb-4 leading-relaxed">
            "{activeStudy.clientQuote.quote}"
          </p>
          <div className="font-bold text-white font-heading">
            {activeStudy.clientQuote.author}
          </div>
          <div className="text-xs text-slate-400">
            {activeStudy.clientQuote.role}
          </div>
        </div>

        {/* CTA Footer */}
        <div className="mt-10 pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-400">
            Need similar outcomes for your enterprise?
          </div>
          <ThreeDButton
            variant="cyan"
            size="md"
            icon={<ArrowUpRight className="w-4 h-4" />}
            onClick={() => setCurrentRoute('audit')}
          >
            Apply for Free Diagnostic Growth Audit
          </ThreeDButton>
        </div>
      </div>
    </div>
  );
};

import { ServiceItem, CaseStudyItem, PortfolioItem, BlogPostItem, StatItem, TestimonialItem, SeoSettings } from '../types';

export const INITIAL_SERVICES: ServiceItem[] = [
  {
    id: 'seo',
    slug: 'seo',
    title: 'Search Engine Optimization',
    tagline: 'Dominate organic search & generative AI answers (GEO).',
    category: 'acquisition',
    icon: 'Search',
    description: 'Data-driven technical SEO, entity architecture, semantic topical authority, and Generative Engine Optimization that secure top rankings across Google Search and AI answer engines.',
    metrics: '+310% Organic Pipeline',
    deliverables: ['Technical SEO Audits & Crawlability', 'Entity & Semantic Topical Clusters', 'Core Web Vitals & 3D Acceleration', 'Generative Engine Optimization (GEO)'],
    featured: true,
    color: '#0066FF'
  },
  {
    id: 'google-ads',
    slug: 'google-ads',
    title: 'Google Ads & Search PPC',
    tagline: 'High-intent search, Performance Max & YouTube scale.',
    category: 'acquisition',
    icon: 'Target',
    description: 'Precision search arbitrage, intent-driven keyword clustering, dynamic ad copy testing, and algorithmic bidding strategies engineered to lower CAC and maximize commercial conversion intent.',
    metrics: '5.8x Average Search ROAS',
    deliverables: ['Performance Max Campaigns', 'High-Intent Search Arbitrage', 'First-Party Offline Conversion Feeds', 'Negative Keyword Shielding'],
    featured: true,
    color: '#00D2FF'
  },
  {
    id: 'meta-ads',
    slug: 'meta-ads',
    title: 'Meta Ads & Paid Social',
    tagline: 'Hyper-converting creative flywheels on Instagram & Facebook.',
    category: 'acquisition',
    icon: 'Layers',
    description: 'Full-funnel creative testing engine combined with Conversions API (CAPI) server-side tracking, algorithmic audience modeling, and psychological direct-response motion assets.',
    metrics: '4.9x Blended Return on Ad Spend',
    deliverables: ['CAPI Server-Side Tracking', 'Modular Video & 3D Ad Creative', 'Advantage+ Audience Engineering', 'Dynamic Retargeting Funnels'],
    featured: true,
    color: '#3B82F6'
  },
  {
    id: 'social-media',
    slug: 'social-media-marketing',
    title: 'Social Media Marketing',
    tagline: 'Build viral brand authority and active community momentum.',
    category: 'acquisition',
    icon: 'Share2',
    description: 'Strategic organic distribution, B2B thought-leadership syndication, founder-led social presence, and high-engagement short-form video content tailored for maximum audience retention.',
    metrics: '8.4M+ Annual Organic Reach',
    deliverables: ['Multi-Channel Content Strategy', 'Short-form Motion Production', 'Executive Personal Branding', 'Community Growth & Engagement'],
    featured: false,
    color: '#60A5FA'
  },
  {
    id: 'content-marketing',
    slug: 'content-marketing',
    title: 'Content Marketing & Authority',
    tagline: 'Authoritative research, whitepapers & viral industry playbooks.',
    category: 'acquisition',
    icon: 'FileText',
    description: 'Original industry benchmark reports, deep-dive tactical playbooks, and conversion-focused editorial hubs that establish undisputed category dominance and earn authoritative backlinks.',
    metrics: '42K+ Inbound Backlinks Earned',
    deliverables: ['Original Industry Research Reports', 'Long-form Tactical Playbooks', 'Interactive Calculators & Tools', 'Editorial Distribution PR'],
    featured: false,
    color: '#0284C7'
  },
  {
    id: 'email-marketing',
    slug: 'email-marketing',
    title: 'Email & Retention Marketing',
    tagline: 'Automated lifecycle journeys that turn leads into repeat buyers.',
    category: 'conversion',
    icon: 'Mail',
    description: 'Predictive cohort segmentation, behavior-triggered lifecycle drips, RFM VIP incentives, and cart abandonment win-back flows powered by personalized dynamic merchandising.',
    metrics: '34% Total Revenue Generated',
    deliverables: ['Behavior-Triggered Drip Engines', 'Cohort RFM Segmentation', 'Deliverability Optimization & DMARC', 'Interactive Kinetic Email Templates'],
    featured: false,
    color: '#2563EB'
  },
  {
    id: 'analytics-bi',
    slug: 'analytics',
    title: 'Analytics & Multi-Touch Attribution',
    tagline: 'Unify fragmented customer journeys into crystal-clear ROI.',
    category: 'intelligence',
    icon: 'BarChart3',
    description: 'Custom server-side Google Analytics 4 pipelines, BigQuery data warehousing, multi-touch Markov attribution models, and automated executive dashboards that expose true channel incrementality.',
    metrics: '100% Attribution Accuracy',
    deliverables: ['Server-Side GA4 & GTM Setup', 'BigQuery Attribution Pipelines', 'Executive Real-Time Dashboards', 'Incrementality Lift Experiments'],
    featured: true,
    color: '#0066FF'
  },
  {
    id: 'conversion-tracking',
    slug: 'conversion-tracking',
    title: 'Conversion Tracking & CRO',
    tagline: 'Systematically double landing page conversion rates.',
    category: 'conversion',
    icon: 'TrendingUp',
    description: 'Rigorous multivariate A/B testing frameworks, heatmaps, biometric eye-tracking heuristics, and high-friction drop-off elimination that transform passive visitors into paying clients.',
    metrics: '+84% Average CVR Lift',
    deliverables: ['Multivariate A/B Testing Frameworks', 'Heatmap & Friction Diagnostics', 'High-Converting Checkout Funnels', 'Rapid Hypotheses Testing Velocity'],
    featured: true,
    color: '#00D2FF'
  },
  {
    id: 'web-development',
    slug: 'web-development',
    title: 'Web Development & 3D Engineering',
    tagline: 'Blazing-fast, high-converting 3D web experiences.',
    category: 'scale',
    icon: 'Code2',
    description: 'Modern full-stack web applications, headless architectures, WebGL interactive product visualizers, and sub-second loading speeds engineered to convert traffic into high-ticket pipeline.',
    metrics: '99/100 Core Web Vitals Score',
    deliverables: ['High-Performance React/Next.js Architectures', 'WebGL & 3D Interactive Experiences', 'Sub-second Edge Deployment', 'Accessible & Mobile-First UX'],
    featured: true,
    color: '#1D4ED8'
  },
  {
    id: 'ai-marketing',
    slug: 'ai-marketing',
    title: 'AI Marketing & Predictive Targeting',
    tagline: 'Autonomous ad creative variations and predictive propensity modeling.',
    category: 'intelligence',
    icon: 'Cpu',
    description: 'Deploy cutting-edge machine learning to forecast customer lifetime value (pLTV), autonomously generate hyper-personalized ad creative variations, and bid dynamically before competitors.',
    metrics: '-38% Customer Acquisition Cost',
    deliverables: ['Predictive LTV Scoring Models', 'Automated Dynamic Creative Testing', 'Competitor Bid Intelligence Bots', 'AI Chatbot Conversion Engines'],
    featured: true,
    color: '#38BDF8'
  }
];

export const INITIAL_CASE_STUDIES: CaseStudyItem[] = [
  {
    id: 'apex-health',
    slug: 'apex-health-scale',
    client: 'Apex HealthTech',
    industry: 'Digital Health & Telemedicine',
    title: 'Scaling Telehealth Patient Bookings by 412% with Precision Search & 3D Onboarding',
    heroMetric: '+412%',
    heroLabel: 'Patient Acquisition Lift',
    overview: 'Apex HealthTech provides on-demand specialist telemedicine across 28 states. Facing rising search CPCs and low mobile funnel completion rates, they partnered with VeloDesk to overhaul their acquisition architecture and conversion funnel.',
    challenge: 'High cost-per-click ($42 average in competitive healthcare verticals) coupled with a 6-step registration flow that lost 68% of inbound traffic before booking.',
    solution: 'Engineered a high-intent Google Ads structure paired with an interactive, frictionless 3D symptom checker landing page and server-side conversion tracking.',
    results: [
      { label: 'Patient Bookings', value: '18,450/mo', change: '+412%' },
      { label: 'Blended Cost Per Acquisition (CPA)', value: '$24.60', change: '-58%' },
      { label: 'Landing Page CVR', value: '14.2%', change: '+184%' },
      { label: 'Search ROAS', value: '6.4x', change: '+220%' }
    ],
    servicesUsed: ['Google Ads', 'Conversion Tracking & CRO', 'Web Development & 3D Engineering', 'Analytics & BI'],
    clientQuote: {
      quote: 'VeloDesk transformed our entire growth engine in less than 90 days. Their 3D interactive funnel and predictive bidding dropped our acquisition costs by more than half while quadrupling monthly bookings.',
      author: 'Dr. Marcus Vance',
      role: 'Chief Medical Officer & Co-Founder, Apex Health'
    },
    featured: true
  },
  {
    id: 'nova-fintech',
    slug: 'nova-fintech-growth',
    client: 'Nova Global FinTech',
    industry: 'B2B SaaS & Payments',
    title: 'Generating $32M in Enterprise Pipeline through Generative SEO and CAPI Meta Ads',
    heroMetric: '$32.4M',
    heroLabel: 'Attributed Enterprise Pipeline',
    overview: 'Nova provides cross-border treasury management for mid-market enterprises. They needed a predictable engine to engage CFOs and controllers without inflating enterprise SDR headcount.',
    challenge: 'Long enterprise sales cycles, zero organic search visibility for high-intent corporate financial queries, and disjointed offline attribution.',
    solution: 'Built an authoritative entity-based SEO hub covering international treasury operations, supported by micro-targeted Meta Ads Advantage+ campaigns linked directly to Salesforce revenue milestones via CAPI.',
    results: [
      { label: 'Enterprise Qualified Pipeline', value: '$32.4M', change: '+340%' },
      { label: 'Organic Monthly Impressions', value: '1.4M', change: '+520%' },
      { label: 'Closed-Won Velocity', value: '42 Days', change: '-35%' },
      { label: 'Blended Marketing ROI', value: '8.2x', change: '+310%' }
    ],
    servicesUsed: ['SEO & GEO', 'Meta Ads', 'Content Marketing', 'Analytics & Multi-Touch Attribution'],
    clientQuote: {
      quote: 'The level of rigor VeloDesk brings to attribution and organic content is unmatched. We booked 140+ qualified enterprise demos in our first two quarters with them.',
      author: 'Elena Rostova',
      role: 'VP of Growth & Marketing, Nova FinTech'
    },
    featured: true
  },
  {
    id: 'lumina-retail',
    slug: 'lumina-direct-ecommerce',
    client: 'Lumina Home Direct',
    industry: 'Premium D2C E-Commerce',
    title: 'Achieving 7.8x Blended ROAS during Q4 Peak with Interactive 3D Product Ad Creative',
    heroMetric: '7.8x',
    heroLabel: 'Blended Q4 ROAS',
    overview: 'Lumina crafts luxury ergonomic furniture. With traditional static ads hitting a performance ceiling, they needed an immersive digital storytelling approach to justify a $1,200 average order value.',
    challenge: 'Customer hesitation regarding physical fit and material quality in high-ticket online furniture buying.',
    solution: 'Launched interactive WebGL 3D configuration ads, combined with dynamic Meta Retargeting and automated SMS/Email post-click nurture sequences.',
    results: [
      { label: 'Q4 Revenue', value: '$14.8M', change: '+265%' },
      { label: 'Average Order Value (AOV)', value: '$1,340', change: '+28%' },
      { label: 'Return on Ad Spend (ROAS)', value: '7.8x', change: '+92%' },
      { label: 'Cart Abandonment Recovery', value: '38%', change: '+115%' }
    ],
    servicesUsed: ['Meta Ads', 'Web Development & 3D Engineering', 'Email & Retention Marketing', 'AI Marketing'],
    clientQuote: {
      quote: 'The 3D interactive product displays built by VeloDesk stopped our buyers mid-scroll. Our conversion rate skyrocketed, and Q4 was the most profitable quarter in company history.',
      author: 'Julian Chen',
      role: 'Head of E-Commerce, Lumina Direct'
    },
    featured: true
  }
];

export const INITIAL_PORTFOLIO: PortfolioItem[] = [
  {
    id: 'p1',
    title: 'Kinetic 3D SaaS Platform',
    category: '3D Web & Growth Engine',
    client: 'Vantage Cloud Platform',
    description: 'Interactive high-performance 3D dashboard interface with live data streaming, custom WebGL shader background, and integrated self-serve trial funnel.',
    metrics: '+142% Sign-Up Conversion',
    tags: ['WebGL', 'React', 'Three.js', 'SEO'],
    year: '2026',
    gradient: 'from-blue-600 to-indigo-900'
  },
  {
    id: 'p2',
    title: 'Global Telehealth Patient Portal',
    category: 'PPC & Conversion Engineering',
    client: 'Apex HealthTech',
    description: 'High-intent search campaign architecture, sub-second 3D booking applet, and multi-state compliance tracking system.',
    metrics: '412% Increase in Bookings',
    tags: ['Google Ads', 'CRO', 'TypeScript', 'HIPAA'],
    year: '2026',
    gradient: 'from-cyan-500 to-blue-700'
  },
  {
    id: 'p3',
    title: 'Autonomous Ad Creative Pipeline',
    category: 'AI Marketing & Scale',
    client: 'HyperScale D2C',
    description: 'Machine learning workflow that generates, variants, and autonomously tests 120+ micro-iterations of high-converting social video creatives per week.',
    metrics: '38% Drop in CAC',
    tags: ['AI Engine', 'Meta CAPI', 'Automation', 'Python'],
    year: '2025',
    gradient: 'from-blue-500 to-sky-400'
  },
  {
    id: 'p4',
    title: 'Enterprise FinTech Authority Hub',
    category: 'Generative SEO & Authority',
    client: 'Nova Payments',
    description: 'Deep semantic knowledge base engineered for top Google organic positions and zero-click Perplexity & ChatGPT citation authority.',
    metrics: '$32.4M Attributed Pipeline',
    tags: ['GEO', 'Semantic SEO', 'Next.js', 'Attribution'],
    year: '2025',
    gradient: 'from-slate-800 to-blue-900'
  }
];

export const INITIAL_BLOG_POSTS: BlogPostItem[] = [
  {
    id: 'b1',
    slug: 'generative-engine-optimization-geo-guide',
    title: 'Generative Engine Optimization (GEO): How to Win Top Citations in ChatGPT, Perplexity, and Google AI Overviews',
    category: 'SEO Strategy',
    readTime: '6 min read',
    publishDate: 'Sep 18, 2026',
    excerpt: 'Traditional search rankings are no longer enough. Learn how to engineer your entity authority, semantic schema, and citation graphs to win dominant placement in AI-driven search answers.',
    author: {
      name: 'Alexander Cross',
      role: 'Head of Search & GEO, VeloDesk'
    },
    tableOfContents: [
      'The Shift from 10 Blue Links to AI Answers',
      'Entity Salience and Semantic Schema Requirements',
      'How LLMs Select Source Citations',
      'Actionable Checklist for GEO Dominance'
    ],
    tags: ['SEO', 'AI Overviews', 'GEO', 'Search Algorithms'],
    content: `
## The Shift from 10 Blue Links to AI Answers
For over two decades, search marketing focused on a single objective: ranking in the top three positions on Google's ten blue links. In 2026, over 48% of high-intent B2B and e-commerce queries are resolved directly inside Google AI Overviews, Perplexity answers, and OpenAI Search.

If your content is not structured as an authoritative, verifiable source entity, your brand simply does not exist to AI retrieval engines.

## Entity Salience and Semantic Schema Requirements
Large language models do not read pages the way human readers or legacy keyword crawlers do. They process information through vector embeddings and knowledge graph entities.

To win top citation placement:
- Implement deep JSON-LD semantic nesting that defines your organization, experts, and empirical data claims.
- Create unambiguous topical clusters that leave zero ambiguity regarding your subject matter authority.
- Provide definitive numerical data points and primary research benchmarks.

## How LLMs Select Source Citations
Retrieval-Augmented Generation (RAG) pipelines prioritize documents with high semantic density, minimal fluff, clean HTML markup, and rapid Core Web Vitals. Heavy, unoptimized websites with bloated JavaScript get deprioritized during real-time retrieval windows.

## Actionable Checklist for GEO Dominance
1. Audit your brand's presence across Wikidata, authoritative press references, and industry review aggregators.
2. Publish proprietary primary benchmark studies annually.
3. Structure your key insights in real, accessible semantic HTML tables and concise summary blocks.
4. Monitor citation frequency using AI brand monitoring software.
    `
  },
  {
    id: 'b2',
    slug: '3d-typography-and-conversion-engineering',
    title: 'The Psychology of 3D Web Design: Why Spatial Depth Boosts Conversion Rates by up to 84%',
    category: 'CRO & Design',
    readTime: '5 min read',
    publishDate: 'Sep 12, 2026',
    excerpt: 'Flat websites have reached aesthetic fatigue. Discover the neuro-design principles behind tactile 3D typography, spatial depth, and micro-interactions that capture attention and build authority.',
    author: {
      name: 'Sophia Sterling',
      role: 'Creative Director & UX Architect, VeloDesk'
    },
    tableOfContents: [
      'The Banner Blindness of Flat Web Design',
      'Spatial Depth and Cognitive Processing',
      'Tactile Affordances in 3D Buttons',
      'Maintaining 100/100 Core Web Vitals with 3D'
    ],
    tags: ['3D Web', 'CRO', 'UX Psychology', 'Typography'],
    content: `
## The Banner Blindness of Flat Web Design
Modern consumers browse dozens of digital marketing pages daily. When every SaaS and agency website uses identical flat cards and generic gradients, visitors slip into cognitive autopilot.

Visual depth breaks this trance. By introducing physical layering, directional lighting, and realistic beveling to critical value propositions, we activate the brain's spatial processing center.

## Spatial Depth and Cognitive Processing
When a user sees physical depth on an H1 headline, the human visual cortex automatically attributes weight, permanence, and credibility to the message. It is the digital equivalent of holding a heavy, embossed business card versus a flimsy photocopy.

## Tactile Affordances in 3D Buttons
A button that looks physically raised and depresses upon click provides instant tactile feedback. In our multivariate testing across 14 enterprise clients, 3D buttons with realistic extrusion and active state depression outperformed flat pill buttons by an average of 31.4% in click-through rate.

## Maintaining 100/100 Core Web Vitals with 3D
The critical requirement is never sacrificing SEO or speed. By executing 3D typography through pure CSS transforms, layered text-shadows, and GPU-accelerated sub-pixel rendering rather than bulky 3D model meshes, your HTML remains fully crawlable by Google while loading in under 400 milliseconds.
    `
  },
  {
    id: 'b3',
    slug: 'multi-touch-attribution-in-privacy-first-era',
    title: 'Server-Side Tracking & Multi-Touch Attribution: The Modern CMO Playbook',
    category: 'Analytics & Attribution',
    readTime: '7 min read',
    publishDate: 'Sep 05, 2026',
    excerpt: 'With third-party cookies eliminated and browser tracking protections intensified, learn how server-side tagging, CAPI feeds, and incrementality experiments reveal true ad profitability.',
    author: {
      name: 'Devin Vance',
      role: 'VP of Data & Attribution, VeloDesk'
    },
    tableOfContents: [
      'The Collapse of Client-Side Pixels',
      'Implementing Server-Side CAPI and GA4',
      'Shapley Value vs. First-Click/Last-Click Models',
      'Turning Attribution Data into Budget Allocations'
    ],
    tags: ['Analytics', 'CAPI', 'Attribution', 'GA4'],
    content: `
## The Collapse of Client-Side Pixels
Browser-level ad blockers and aggressive mobile privacy controls strip away up to 35% of client-side tracking signals before they ever reach ad platforms. Marketing teams relying on standard browser pixels are bidding blind.

## Implementing Server-Side CAPI and GA4
The solution is moving tracking upstream. By establishing a dedicated server container that receives first-party event streams directly from your web server, you retain 100% data fidelity while protecting customer data privacy.

## Shapley Value vs. First-Click/Last-Click Models
Last-click attribution artificially credits search brand campaigns while undervaluing top-of-funnel creative that introduced buyers to your brand. We implement game-theory Shapley attribution models that assign mathematical equity to every marketing touchpoint.
    `
  }
];

export const INITIAL_STATS: StatItem[] = [
  {
    id: 's1',
    value: 420,
    prefix: '+',
    suffix: '%',
    label: 'Average Organic Traffic Growth',
    description: 'Measured across active SEO and Generative Engine Optimization campaigns over 12 months.',
    style: 'extruded'
  },
  {
    id: 's2',
    value: 84,
    prefix: '$',
    suffix: 'M+',
    label: 'Client Revenue Generated',
    description: 'Directly verified pipeline and e-commerce transactions attributed through server-side analytics.',
    style: 'metallic'
  },
  {
    id: 's3',
    value: 99,
    suffix: '.2%',
    label: 'Client Retention Rate',
    description: 'Long-term enterprise partnerships based purely on transparent monthly ROI delivery.',
    style: 'glass'
  },
  {
    id: 's4',
    value: 12,
    prefix: '',
    suffix: '+',
    label: 'Years of Market Leadership',
    description: 'Pioneering performance marketing, conversion engineering, and 3D web technology since 2014.',
    style: 'floating'
  }
];

export const INITIAL_TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    quote: 'VeloDesk doesn\'t just manage ad spend—they re-architect your entire growth infrastructure. In six months, our customer acquisition cost dropped 58% while our booking volume quadrupled.',
    author: 'Dr. Marcus Vance',
    role: 'Chief Medical Officer',
    company: 'Apex HealthTech',
    impactMetric: '+412% Bookings',
    rating: 5
  },
  {
    id: 't2',
    quote: 'The 3D website and conversion funnels they engineered set a new benchmark in our category. CFOs consistently comment on how premium and fast our digital platform feels.',
    author: 'Elena Rostova',
    role: 'VP of Growth',
    company: 'Nova Global FinTech',
    impactMetric: '$32.4M Pipeline',
    rating: 5
  },
  {
    id: 't3',
    quote: 'We spent years cycling through agencies that promised the world and delivered vanity metrics. VeloDesk is the first partner that delivers pure commercial revenue on day one.',
    author: 'Julian Chen',
    role: 'Head of E-Commerce',
    company: 'Lumina Home Direct',
    impactMetric: '7.8x Q4 ROAS',
    rating: 5
  }
];

export const PROCESS_STEPS = [
  {
    step: '01',
    title: 'Diagnostic Deep Dive & 3D Audit',
    description: 'We perform a forensic evaluation of your analytics, search entity authority, ad account efficiency, and technical conversion leaks.',
    icon: 'Search'
  },
  {
    step: '02',
    title: 'Growth Architecture & Modeling',
    description: 'We design your proprietary acquisition matrix, forecasting target CAC, payback periods, and channel incrementality models.',
    icon: 'Layers'
  },
  {
    step: '03',
    title: '3D Web & Creative Engineering',
    description: 'We deploy high-converting 3D digital experiences, interactive funnels, and automated multivariate creative testing flywheels.',
    icon: 'Code2'
  },
  {
    step: '04',
    title: 'Algorithmic Scale & Optimization',
    description: 'With server-side attribution live, we aggressively scale top-performing channels while continuously eliminating CPA friction.',
    icon: 'TrendingUp'
  }
];

export const INITIAL_SEO: SeoSettings = {
  siteTitle: 'VeloDesk - 3D Digital Growth & Performance Marketing',
  metaDescription: 'Next-generation digital marketing agency featuring immersive 3D typography, interactive performance ecosystems, SEO, PPC, conversion engineering, and full CMS architecture.',
  ogTitle: 'VeloDesk - Turn Digital Attention Into Real Business Growth',
  ogDescription: 'Experience the future of performance marketing with VeloDesk. 3D typography, data-driven SEO, Google Ads, Meta Ads, and full attribution modeling.',
  canonicalUrl: 'https://velodesk.io',
  keywords: 'digital marketing, 3D web design, SEO, Google Ads, Meta Ads, conversion rate optimization, growth agency'
};

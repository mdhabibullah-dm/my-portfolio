import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { useCms } from '../../context/CmsContext';

export const ThreeDBackground: React.FC<{ className?: string }> = ({ className = '' }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const { reducedMotion, threeDQuality } = useCms();

  useEffect(() => {
    if (!mountRef.current) return;
    if (reducedMotion || threeDQuality === 'low') return;

    const container = mountRef.current;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x070b14, 0.035);

    // Camera
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.set(0, 0, 16);

    // Renderer
    let renderer: THREE.WebGLRenderer | null = null;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: threeDQuality === 'high',
        alpha: true,
        powerPreference: 'high-performance',
      });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, threeDQuality === 'high' ? 2 : 1));
      container.appendChild(renderer.domElement);
    } catch (e) {
      console.warn('WebGL not supported or failed to initialize', e);
      return;
    }

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const blueRimLight = new THREE.DirectionalLight(0x0066ff, 3.5);
    blueRimLight.position.set(12, 10, 8);
    scene.add(blueRimLight);

    const cyanPointLight = new THREE.PointLight(0x00d2ff, 4.0, 30);
    cyanPointLight.position.set(-8, -4, 6);
    scene.add(cyanPointLight);

    // Group for all floating objects
    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    // 1. Digital Marketing Floating Objects
    const objects: { mesh: THREE.Object3D; rotSpeed: { x: number; y: number; z: number }; initialY: number; floatSpeed: number }[] = [];

    // Metallic Material & Blue Glass Material
    const darkGlassMat = new THREE.MeshStandardMaterial({
      color: 0x0f1b33,
      metalness: 0.8,
      roughness: 0.2,
      wireframe: false,
    });

    const blueCyberMat = new THREE.MeshStandardMaterial({
      color: 0x0066ff,
      emissive: 0x002e7a,
      metalness: 0.9,
      roughness: 0.1,
    });

    const cyanGlowMat = new THREE.MeshStandardMaterial({
      color: 0x00d2ff,
      emissive: 0x0088cc,
      metalness: 0.5,
      roughness: 0.2,
    });

    const wireMat = new THREE.MeshBasicMaterial({
      color: 0x0066ff,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });

    // Object A: Analytics 3D Growth Cylinder Bar Chart (Representing Analytics & ROI)
    const chartGroup = new THREE.Group();
    const barHeights = [1.2, 2.0, 1.6, 2.8, 3.4];
    barHeights.forEach((h, i) => {
      const barGeo = new THREE.CylinderGeometry(0.18, 0.18, h, 16);
      const barMesh = new THREE.Mesh(barGeo, i === barHeights.length - 1 ? cyanGlowMat : blueCyberMat);
      barMesh.position.set((i - 2) * 0.55, h / 2, 0);
      chartGroup.add(barMesh);
    });
    chartGroup.position.set(-6.5, 2.5, -4);
    chartGroup.scale.set(0.7, 0.7, 0.7);
    worldGroup.add(chartGroup);
    objects.push({ mesh: chartGroup, rotSpeed: { x: 0.003, y: 0.005, z: 0.001 }, initialY: 2.5, floatSpeed: 0.8 });

    // Object B: Torus Ring (Representing Search Engine / Target intent)
    const torusGeo = new THREE.TorusGeometry(1.4, 0.2, 16, 40);
    const torusMesh = new THREE.Mesh(torusGeo, blueCyberMat);
    torusMesh.position.set(7.5, 3.0, -5);
    worldGroup.add(torusMesh);
    objects.push({ mesh: torusMesh, rotSpeed: { x: 0.006, y: 0.008, z: 0.004 }, initialY: 3.0, floatSpeed: 1.1 });

    // Object C: 3D Data Cubes with Wireframe overlays (Representing Data warehousing & BigQuery)
    for (let i = 0; i < 4; i++) {
      const cubeSize = 0.8 + i * 0.2;
      const cubeGeo = new THREE.BoxGeometry(cubeSize, cubeSize, cubeSize);
      const cubeMesh = new THREE.Mesh(cubeGeo, darkGlassMat);
      const wireOverlay = new THREE.Mesh(cubeGeo, wireMat);
      cubeMesh.add(wireOverlay);

      const posX = i % 2 === 0 ? -5 - i * 1.2 : 6 + i * 1.2;
      const posY = -3 + i * 1.5;
      const posZ = -6 - i * 2;
      cubeMesh.position.set(posX, posY, posZ);
      worldGroup.add(cubeMesh);
      objects.push({
        mesh: cubeMesh,
        rotSpeed: { x: 0.004 * (i + 1), y: 0.003 * (i + 1), z: 0.002 },
        initialY: posY,
        floatSpeed: 0.9 + i * 0.2,
      });
    }

    // Object D: Conversion Funnel / Cone (Representing CRO & Sales Funnels)
    const coneGeo = new THREE.ConeGeometry(1.2, 2.2, 24, 1, true);
    const coneMesh = new THREE.Mesh(coneGeo, darkGlassMat);
    coneMesh.position.set(5.5, -3.2, -3);
    coneMesh.rotation.x = Math.PI * 0.85;
    worldGroup.add(coneMesh);
    objects.push({ mesh: coneMesh, rotSpeed: { x: 0.002, y: 0.006, z: 0.001 }, initialY: -3.2, floatSpeed: 1.0 });

    // Object E: 3D Connected Nodes Network (Representing attribution, SEO graphs, AI algorithms)
    const nodeCount = 28;
    const nodeGeo = new THREE.SphereGeometry(0.12, 12, 12);
    const nodePositions: THREE.Vector3[] = [];
    const nodeGroup = new THREE.Group();

    for (let i = 0; i < nodeCount; i++) {
      const nodeMesh = new THREE.Mesh(nodeGeo, i % 3 === 0 ? cyanGlowMat : blueCyberMat);
      const pos = new THREE.Vector3(
        (Math.random() - 0.5) * 22,
        (Math.random() - 0.5) * 14,
        (Math.random() - 0.5) * 12 - 4
      );
      nodeMesh.position.copy(pos);
      nodeGroup.add(nodeMesh);
      nodePositions.push(pos);
    }

    // Connect close nodes with lines
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x0066ff,
      transparent: true,
      opacity: 0.25,
    });
    const lineGeometry = new THREE.BufferGeometry();
    const linePoints: number[] = [];

    for (let i = 0; i < nodeCount; i++) {
      for (let j = i + 1; j < nodeCount; j++) {
        if (nodePositions[i].distanceTo(nodePositions[j]) < 5.5) {
          linePoints.push(nodePositions[i].x, nodePositions[i].y, nodePositions[i].z);
          linePoints.push(nodePositions[j].x, nodePositions[j].y, nodePositions[j].z);
        }
      }
    }
    lineGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePoints, 3));
    const lines = new THREE.LineSegments(lineGeometry, lineMat);
    nodeGroup.add(lines);
    worldGroup.add(nodeGroup);
    objects.push({ mesh: nodeGroup, rotSpeed: { x: 0.0008, y: 0.0012, z: 0.0005 }, initialY: 0, floatSpeed: 0.4 });

    // Particle Cloud (digital flow of audience signals)
    const particleCount = threeDQuality === 'high' ? 220 : 100;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 35;
      particlePositions[i + 1] = (Math.random() - 0.5) * 25;
      particlePositions[i + 2] = (Math.random() - 0.5) * 20 - 5;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.08,
      transparent: true,
      opacity: 0.6,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    scene.add(particleSystem);

    // Mouse Interaction Parallax
    let targetMouseX = 0;
    let targetMouseY = 0;
    let currentMouseX = 0;
    let currentMouseY = 0;

    const onMouseMove = (e: MouseEvent) => {
      targetMouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetMouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener('mousemove', onMouseMove, { passive: true });

    // Resize handler
    const onResize = () => {
      if (!container || !renderer) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // IntersectionObserver to pause rendering when out of viewport
    let isVisible = true;
    const observer = new IntersectionObserver(([entry]) => {
      isVisible = entry.isIntersecting;
    });
    observer.observe(container);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (!isVisible) return;

      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Smooth camera interpolation based on mouse
      currentMouseX += (targetMouseX - currentMouseX) * 0.04;
      currentMouseY += (targetMouseY - currentMouseY) * 0.04;

      camera.position.x = currentMouseX * 1.5;
      camera.position.y = -currentMouseY * 1.2;
      camera.lookAt(0, 0, 0);

      // Rotate and float objects
      objects.forEach((obj) => {
        obj.mesh.rotation.x += obj.rotSpeed.x;
        obj.mesh.rotation.y += obj.rotSpeed.y;
        obj.mesh.rotation.z += obj.rotSpeed.z;
        obj.mesh.position.y = obj.initialY + Math.sin(time * obj.floatSpeed) * 0.35;
      });

      // Slowly rotate particle system
      particleSystem.rotation.y = time * 0.02;

      if (renderer) {
        renderer.render(scene, camera);
      }
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', onResize);
      observer.disconnect();

      if (renderer && renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer?.dispose();
    };
  }, [reducedMotion, threeDQuality]);

  return (
    <div
      ref={mountRef}
      className={`absolute inset-0 pointer-events-none overflow-hidden z-0 ${className}`}
      style={{
        background: 'radial-gradient(ellipse at 50% 30%, rgba(0, 102, 255, 0.12) 0%, rgba(7, 11, 20, 0.98) 75%)',
      }}
    />
  );
};

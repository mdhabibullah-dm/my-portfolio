import React, { useEffect, useState, useRef } from 'react';
import { StatItem } from '../../types';
import { ThreeDText } from './ThreeDText';
import { useCms } from '../../context/CmsContext';

export interface ThreeDStatProps {
  stat: StatItem;
  className?: string;
}

export const ThreeDStat: React.FC<ThreeDStatProps> = ({ stat, className = '' }) => {
  const { reducedMotion } = useCms();
  const [displayValue, setDisplayValue] = useState(reducedMotion ? stat.value : 0);
  const [isVisible, setIsVisible] = useState(false);
  const statRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (statRef.current) {
      observer.observe(statRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible || reducedMotion) {
      setDisplayValue(stat.value);
      return;
    }

    let start = 0;
    const duration = 1600; // ms
    const startTime = performance.now();

    const animateNumber = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // easeOutExpo
      const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = Math.floor(ease * stat.value);
      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(animateNumber);
      } else {
        setDisplayValue(stat.value);
      }
    };

    requestAnimationFrame(animateNumber);
  }, [isVisible, stat.value, reducedMotion]);

  return (
    <div
      ref={statRef}
      className={`
        relative p-6 sm:p-8 rounded-2xl preserve-3d
        bg-gradient-to-b from-[#111A2E]/80 to-[#0A101D]/90
        border border-slate-700/50 hover:border-blue-500/60
        transition-all duration-300 hover:-translate-y-1.5
        shadow-[0_10px_30px_rgba(0,0,0,0.6)]
        ${className}
      `.trim()}
    >
      {/* 3D Value Counter */}
      <div className="flex items-baseline gap-1 mb-2">
        <ThreeDText
          as="span"
          styleVariant={stat.style}
          depth="extreme"
          size="text-4xl sm:text-5xl lg:text-6xl font-black"
          interactive={true}
          className="tracking-tight"
        >
          {stat.prefix}{displayValue}{stat.suffix}
        </ThreeDText>
      </div>

      {/* Real HTML label & description */}
      <h3 className="text-base sm:text-lg font-bold text-white mb-1.5 font-heading">
        {stat.label}
      </h3>
      <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
        {stat.description}
      </p>

      {/* Cyber blue corner node */}
      <div className="absolute top-3 right-3 w-1.5 h-1.5 rounded-full bg-[#00D2FF] opacity-60 shadow-[0_0_8px_#00D2FF]" />
    </div>
  );
};

import React, { useState, useRef } from 'react';
import { useCms } from '../../context/CmsContext';

export interface ThreeDCardProps {
  children: React.ReactNode;
  className?: string;
  depthIntensity?: number; // default 15
  glowColor?: string;
  interactive?: boolean;
  onClick?: () => void;
  id?: string;
}

export const ThreeDCard: React.FC<ThreeDCardProps> = ({
  children,
  className = '',
  depthIntensity = 15,
  glowColor = 'rgba(0, 102, 255, 0.25)',
  interactive = true,
  onClick,
  id,
}) => {
  const { reducedMotion, threeDQuality } = useCms();
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!interactive || reducedMotion || threeDQuality === 'low') return;
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const factor = depthIntensity / 10;
    const rotateX = ((y - centerY) / centerY) * -8 * factor;
    const rotateY = ((x - centerX) / centerX) * 8 * factor;

    setRotate({ x: rotateX, y: rotateY });
    setGlarePos({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
    });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
    setGlarePos({ x: 50, y: 50 });
  };

  const transformStyle: React.CSSProperties = {
    transform: interactive && !reducedMotion && threeDQuality !== 'low' && isHovered
      ? `perspective(1000px) rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) translateZ(16px) scale3d(1.02, 1.02, 1.02)`
      : interactive && !reducedMotion && threeDQuality !== 'low'
      ? 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0px) scale3d(1, 1, 1)'
      : undefined,
    transition: isHovered ? 'transform 0.1s ease-out, box-shadow 0.2s ease-out' : 'transform 0.4s ease-out, box-shadow 0.4s ease-out',
    boxShadow: isHovered
      ? `0 20px 40px -15px rgba(0, 0, 0, 0.9), 0 0 35px ${glowColor}, inset 0 1px 0 rgba(255, 255, 255, 0.15)`
      : '0 10px 30px -15px rgba(0, 0, 0, 0.7), inset 0 1px 0 rgba(255, 255, 255, 0.06)',
  };

  return (
    <div
      ref={cardRef}
      id={id}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={transformStyle}
      className={`
        relative rounded-2xl preserve-3d overflow-hidden
        bg-gradient-to-b from-[#111A2E]/90 to-[#0A101D]/95
        border border-slate-700/50 hover:border-blue-500/60
        backdrop-blur-md
        ${onClick ? 'cursor-pointer' : ''}
        ${className}
      `.trim()}
    >
      {/* Dynamic Specular Glare */}
      {interactive && !reducedMotion && threeDQuality !== 'low' && (
        <div
          className="pointer-events-none absolute inset-0 z-20 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            opacity: isHovered ? 0.35 : 0,
            background: `radial-gradient(circle 350px at ${glarePos.x}% ${glarePos.y}%, rgba(255, 255, 255, 0.22), transparent 80%)`,
          }}
        />
      )}

      {/* Subtle blue rim highlight */}
      <div className="pointer-events-none absolute -inset-[1px] rounded-2xl bg-gradient-to-r from-blue-600/20 via-cyan-500/10 to-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      {/* Card Content with 3D translation */}
      <div className="relative z-10 p-6 md:p-8 flex flex-col h-full [transform:translateZ(20px)]">
        {children}
      </div>
    </div>
  );
};

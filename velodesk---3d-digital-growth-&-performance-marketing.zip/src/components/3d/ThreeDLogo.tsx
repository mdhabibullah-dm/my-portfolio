import React from 'react';
import { useCms } from '../../context/CmsContext';

export interface ThreeDLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  interactive?: boolean;
  className?: string;
  onClick?: () => void;
}

export const ThreeDLogo: React.FC<ThreeDLogoProps> = ({
  size = 'md',
  showText = true,
  interactive = true,
  className = '',
  onClick,
}) => {
  const { reducedMotion } = useCms();

  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  }[size];

  const textSizes = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl',
    xl: 'text-4xl',
  }[size];

  return (
    <div
      onClick={onClick}
      className={`group inline-flex items-center gap-3 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {/* 3D Geometric V Crest */}
      <div 
        className={`relative ${iconSizes} preserve-3d transition-transform duration-300 ${!reducedMotion && interactive ? 'group-hover:rotate-y-12 group-hover:scale-105' : ''}`}
        style={{
          filter: 'drop-shadow(0 4px 10px rgba(0, 102, 255, 0.5)) drop-shadow(0 8px 20px rgba(0, 0, 0, 0.7))',
        }}
      >
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
        >
          {/* Defs for gradients & filters */}
          <defs>
            <linearGradient id="veloPrimary" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38BDF8" />
              <stop offset="40%" stopColor="#0066FF" />
              <stop offset="100%" stopColor="#00358A" />
            </linearGradient>
            <linearGradient id="veloSecondary" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00D2FF" />
              <stop offset="100%" stopColor="#0055D4" />
            </linearGradient>
            <linearGradient id="veloBevel" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#0066FF" stopOpacity="0" />
            </linearGradient>
            <filter id="circuitGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Extruded Back Shadow Layer */}
          <polygon
            points="18,18 42,78 58,78 82,18 66,18 50,62 34,18"
            fill="#031633"
            transform="translate(0, 5)"
          />

          {/* Main 3D V Body */}
          <polygon
            points="18,16 42,76 58,76 82,16 66,16 50,60 34,16"
            fill="url(#veloPrimary)"
          />

          {/* Right Speed Wing Highlight */}
          <polygon
            points="50,60 58,76 82,16 74,16"
            fill="url(#veloSecondary)"
            opacity="0.9"
          />

          {/* Top Bevel Rim Specular Reflection */}
          <polygon
            points="18,16 34,16 26,18"
            fill="url(#veloBevel)"
          />
          <polygon
            points="66,16 82,16 74,18"
            fill="url(#veloBevel)"
          />

          {/* Cyber Circuit Node Indicator */}
          <circle cx="50" cy="46" r="4.5" fill="#00D2FF" filter="url(#circuitGlow)" />
          <line x1="50" y1="46" x2="68" y2="28" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 3" />
          <circle cx="68" cy="28" r="2.5" fill="#FFFFFF" />
        </svg>
      </div>

      {/* Brand Wordmark with 3D Depth */}
      {showText && (
        <div className="flex items-baseline">
          <span 
            className={`font-heading font-black tracking-tight text-white ${textSizes}`}
            style={{
              textShadow: '0 1px 0 #0d4bb3, 0 2px 0 #093782, 0 3px 0 #05265c, 0 6px 12px rgba(0,0,0,0.8)',
            }}
          >
            VELO
          </span>
          <span 
            className={`font-heading font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#00D2FF] to-[#38BDF8] ${textSizes}`}
            style={{
              filter: 'drop-shadow(0 2px 4px rgba(0, 102, 255, 0.4))',
            }}
          >
            DESK
          </span>
          <span className="ml-1 w-1.5 h-1.5 rounded-full bg-[#00D2FF] shadow-[0_0_8px_#00D2FF]" />
        </div>
      )}
    </div>
  );
};

import React, { useState, useRef } from 'react';
import { ThreeDTextStyle, ThreeDDepth } from '../../types';
import { useCms } from '../../context/CmsContext';

export interface ThreeDTextProps {
  text?: string;
  children?: React.ReactNode;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'span' | 'p' | 'div';
  styleVariant?: ThreeDTextStyle;
  depth?: ThreeDDepth;
  size?: string;
  weight?: string;
  glow?: boolean;
  interactive?: boolean;
  animation?: boolean;
  className?: string;
  id?: string;
}

export const ThreeDText: React.FC<ThreeDTextProps> = ({
  text,
  children,
  as: Component = 'span',
  styleVariant = 'extruded',
  depth = 'medium',
  size = '',
  weight = 'font-bold',
  glow = false,
  interactive = false,
  animation = false,
  className = '',
  id,
}) => {
  const { reducedMotion, threeDQuality } = useCms();
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLElement | null>(null);

  const content = text ?? children;

  // Depth shadow configurations based on depth prop
  const getExtrusionShadow = () => {
    switch (depth) {
      case 'subtle':
        return '0 1px 0 #0d4bb3, 0 2px 0 #093782, 0 4px 6px rgba(0,0,0,0.5)';
      case 'deep':
        return '0 1px 0 #0d4bb3, 0 2px 0 #0b419c, 0 3px 0 #093782, 0 4px 0 #072f70, 0 5px 0 #05265c, 0 6px 0 #041f4b, 0 8px 1px rgba(0,0,0,0.6), 0 14px 20px rgba(0,0,0,0.8)';
      case 'extreme':
        return '0 1px 0 #1259d6, 0 2px 0 #0f4db8, 0 3px 0 #0c429c, 0 4px 0 #0a3680, 0 5px 0 #082b66, 0 6px 0 #06214f, 0 7px 0 #05193d, 0 8px 0 #03122c, 0 10px 0 #020c1e, 0 12px 2px rgba(0,0,0,0.6), 0 20px 40px rgba(0,102,255,0.4), 0 30px 60px rgba(0,0,0,0.9)';
      case 'medium':
      default:
        return '0 1px 0 #0d4bb3, 0 2px 0 #093782, 0 3px 0 #072f70, 0 4px 0 #05265c, 0 5px 1px rgba(0,0,0,0.5), 0 8px 15px rgba(0,0,0,0.7)';
    }
  };

  const getStyleClasses = () => {
    switch (styleVariant) {
      case 'floating':
        return 'text-white text-3d-floating';
      case 'glass':
        return 'text-3d-glass font-extrabold';
      case 'metallic':
        return 'text-3d-metallic font-black';
      case 'soft-depth':
        return 'text-slate-100 text-3d-soft';
      case 'outline-extruded':
        return 'text-3d-outline font-black';
      case 'layered-perspective':
        return 'text-white text-3d-layered';
      case 'extruded':
      default:
        return 'text-white text-3d-extruded';
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    if (!interactive || reducedMotion || threeDQuality === 'low') return;
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -12;
    const rotateY = ((x - centerX) / centerX) * 12;

    setRotate({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const customInlineStyle: React.CSSProperties = {
    display: Component === 'span' ? 'inline-block' : undefined,
    transform: interactive && !reducedMotion && threeDQuality !== 'low' && isHovered
      ? `perspective(800px) rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) translateZ(12px) scale(1.02)`
      : interactive && !reducedMotion && threeDQuality !== 'low'
      ? 'perspective(800px) rotateX(0deg) rotateY(0deg) translateZ(0px)'
      : undefined,
    transition: isHovered ? 'transform 0.08s ease-out' : 'transform 0.4s ease-out',
    textShadow: styleVariant === 'extruded' && (depth === 'deep' || depth === 'extreme' || depth === 'subtle')
      ? getExtrusionShadow()
      : undefined,
    filter: glow ? 'drop-shadow(0 0 20px rgba(0, 102, 255, 0.6))' : undefined,
  };

  return (
    <Component
      ref={containerRef as any}
      id={id}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={customInlineStyle}
      className={`
        ${weight} 
        ${size} 
        ${getStyleClasses()} 
        ${animation && !reducedMotion ? 'animate-pulse' : ''}
        ${interactive ? 'cursor-pointer select-none' : ''}
        transition-colors duration-200
        ${className}
      `.trim()}
    >
      {content}
    </Component>
  );
};

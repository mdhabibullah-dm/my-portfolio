import React from 'react';
import * as Icons from 'lucide-react';
import { useCms } from '../../context/CmsContext';

export interface ThreeDIconProps {
  name: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  color?: string;
  glow?: boolean;
  className?: string;
}

export const ThreeDIcon: React.FC<ThreeDIconProps> = ({
  name,
  size = 'md',
  color = '#0066FF',
  glow = true,
  className = '',
}) => {
  const { reducedMotion } = useCms();
  const IconComponent = (Icons as any)[name] || Icons.Zap;

  const sizeClasses = {
    sm: 'w-8 h-8 p-1.5 rounded-lg',
    md: 'w-12 h-12 p-2.5 rounded-xl',
    lg: 'w-16 h-16 p-3.5 rounded-2xl',
    xl: 'w-20 h-20 p-4.5 rounded-3xl',
  }[size];

  const iconSizes = {
    sm: 16,
    md: 22,
    lg: 30,
    xl: 38,
  }[size];

  return (
    <div
      className={`
        relative inline-flex items-center justify-center shrink-0 preserve-3d
        bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700/60
        transition-transform duration-300 ${!reducedMotion ? 'group-hover:scale-110 group-hover:-translate-y-1' : ''}
        ${sizeClasses}
        ${className}
      `.trim()}
      style={{
        boxShadow: `
          0 1px 0 rgba(255, 255, 255, 0.2) inset,
          0 4px 0 #070d1a,
          0 8px 16px rgba(0, 0, 0, 0.6)
          ${glow ? `, 0 0 20px ${color}40` : ''}
        `,
      }}
    >
      {/* Specular inner bevel */}
      <div className="absolute inset-0 rounded-[inherit] bg-gradient-to-tr from-transparent via-white/5 to-white/20 pointer-events-none" />

      {/* Render Icon */}
      <IconComponent
        size={iconSizes}
        color={color}
        className="relative z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
      />
    </div>
  );
};

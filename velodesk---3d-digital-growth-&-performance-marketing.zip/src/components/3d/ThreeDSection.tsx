import React from 'react';
import { ThreeDHeading } from './ThreeDHeading';
import { ThreeDText } from './ThreeDText';
import { ThreeDTextStyle } from '../../types';

export interface ThreeDSectionProps {
  id?: string;
  badge?: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  headingStyle?: ThreeDTextStyle;
  className?: string;
  centered?: boolean;
}

export const ThreeDSection: React.FC<ThreeDSectionProps> = ({
  id,
  badge,
  title,
  subtitle,
  children,
  headingStyle = 'layered-perspective',
  className = '',
  centered = true,
}) => {
  return (
    <section id={id} className={`py-16 sm:py-24 px-4 sm:px-6 lg:px-8 relative ${className}`}>
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className={`mb-12 sm:mb-16 ${centered ? 'text-center mx-auto max-w-3xl' : 'max-w-3xl'}`}>
          {badge && (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full mb-4 bg-blue-950/60 border border-blue-500/30 text-xs font-bold uppercase tracking-wider text-blue-400 shadow-[0_2px_10px_rgba(0,102,255,0.2)] backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D2FF]" />
              {badge}
            </div>
          )}

          <div className="mb-4">
            <ThreeDHeading
              level={2}
              styleVariant={headingStyle}
              depth="deep"
              interactive={true}
              className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight"
            >
              {title}
            </ThreeDHeading>
          </div>

          {subtitle && (
            <ThreeDText
              as="p"
              styleVariant="soft-depth"
              depth="subtle"
              size="text-base sm:text-lg"
              className="text-slate-400 leading-relaxed"
            >
              {subtitle}
            </ThreeDText>
          )}
        </div>

        {/* Section Body */}
        {children}
      </div>
    </section>
  );
};

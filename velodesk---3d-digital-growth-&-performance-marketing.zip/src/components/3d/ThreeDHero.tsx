import React from 'react';
import { ThreeDText } from './ThreeDText';
import { ThreeDButton } from './ThreeDButton';
import { ThreeDLogo } from './ThreeDLogo';
import { ThreeDBackground } from './ThreeDBackground';
import { useCms } from '../../context/CmsContext';
import { ArrowUpRight, ShieldCheck, Sparkles, TrendingUp, Layers } from 'lucide-react';

export const ThreeDHero: React.FC = () => {
  const { setCurrentRoute } = useCms();

  return (
    <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      {/* 3D WebGL Digital Marketing Ecosystem Background */}
      <ThreeDBackground />

      {/* Cyber Grid Lines and Ambient Glow */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(0, 102, 255, 0.15) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(0, 102, 255, 0.15) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
          maskImage: 'radial-gradient(ellipse at 50% 50%, black 40%, transparent 80%)',
          WebkitMaskImage: 'radial-gradient(ellipse at 50% 50%, black 40%, transparent 80%)',
        }}
      />

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-6xl mx-auto text-center flex flex-col items-center">
        {/* Floating Category Pill with 3D Bevel */}
        <div 
          className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full mb-8
                     bg-gradient-to-r from-blue-950/80 via-slate-900/90 to-blue-950/80
                     border border-blue-500/40 text-blue-300 text-xs sm:text-sm font-semibold tracking-wide
                     shadow-[0_4px_15px_rgba(0,102,255,0.25),inset_0_1px_0_rgba(255,255,255,0.2)]
                     backdrop-blur-md animate-pulse"
        >
          <Sparkles className="w-4 h-4 text-[#00D2FF]" />
          <span>Next-Generation 3D Performance Marketing & Engineering</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#00D2FF]" />
        </div>

        {/* MAIN 3D HEADLINE - REAL HTML H1 */}
        <h1 className="sr-only">Turn Digital Attention Into Real Business Growth.</h1>
        <div className="mb-6 max-w-5xl">
          <ThreeDText
            as="h1"
            id="hero-main-title"
            styleVariant="extruded"
            depth="extreme"
            interactive={true}
            glow={true}
            size="text-4xl sm:text-6xl md:text-7xl lg:text-[5.25rem] font-heading font-black tracking-tight"
            className="leading-[1.08] text-white"
          >
            Turn Digital Attention Into Real Business Growth.
          </ThreeDText>
        </div>

        {/* 3D SUBHEADLINE */}
        <div className="max-w-3xl mx-auto mb-10">
          <ThreeDText
            as="p"
            styleVariant="soft-depth"
            depth="subtle"
            interactive={false}
            size="text-lg sm:text-xl md:text-2xl font-medium"
            className="text-slate-300 leading-relaxed"
          >
            VeloDesk architects high-converting 3D digital platforms, precision Google & Meta acquisition engines, and server-side attribution systems engineered for market leaders.
          </ThreeDText>
        </div>

        {/* 3D PHYSICAL CTA BUTTONS */}
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 mb-14">
          <ThreeDButton
            id="hero-cta-audit"
            variant="cyan"
            size="lg"
            icon={<ArrowUpRight className="w-5 h-5" />}
            glow={true}
            onClick={() => setCurrentRoute('audit')}
          >
            Get a Free 3D Audit
          </ThreeDButton>

          <ThreeDButton
            id="hero-cta-services"
            variant="secondary"
            size="lg"
            icon={<Layers className="w-5 h-5" />}
            onClick={() => setCurrentRoute('services')}
          >
            Explore Services
          </ThreeDButton>

          <ThreeDButton
            id="hero-cta-casestudies"
            variant="glass"
            size="lg"
            icon={<TrendingUp className="w-5 h-5" />}
            onClick={() => setCurrentRoute('casestudies')}
          >
            View Real Case Studies
          </ThreeDButton>
        </div>

        {/* Trust Badges & Verified Attribution Proof */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-8 pt-6 border-t border-slate-800/80 w-full max-w-4xl text-left">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
            <div>
              <div className="text-xs text-slate-400 font-medium">Attribution Model</div>
              <div className="text-sm font-bold text-slate-200">100% Server CAPI</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-400 shadow-[0_0_8px_#60a5fa]" />
            <div>
              <div className="text-xs text-slate-400 font-medium">Web Performance</div>
              <div className="text-sm font-bold text-slate-200">99/100 Core Vitals</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-[#00D2FF] shadow-[0_0_8px_#00d2ff]" />
            <div>
              <div className="text-xs text-slate-400 font-medium">Average ROAS Lift</div>
              <div className="text-sm font-bold text-slate-200">5.8x Blended</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-purple-400 shadow-[0_0_8px_#c084fc]" />
            <div>
              <div className="text-xs text-slate-400 font-medium">Client Retention</div>
              <div className="text-sm font-bold text-slate-200">99.2% Verified</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { useCms } from '../../context/CmsContext';

export interface ThreeDButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'cyan' | 'ghost' | 'glass';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  depth?: 'subtle' | 'medium' | 'deep';
  glow?: boolean;
}

export const ThreeDButton: React.FC<ThreeDButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'right',
  depth = 'medium',
  glow = false,
  className = '',
  id,
  onClick,
  ...props
}) => {
  const { reducedMotion } = useCms();
  const [isPressed, setIsPressed] = useState(false);

  // Size padding and font
  const sizeClasses = {
    sm: 'px-4 py-2 text-xs font-semibold rounded-lg gap-1.5',
    md: 'px-6 py-3 text-sm font-bold rounded-xl gap-2',
    lg: 'px-8 py-4 text-base font-bold rounded-xl gap-2.5',
    xl: 'px-10 py-5 text-lg font-extrabold rounded-2xl gap-3 tracking-wide',
  }[size];

  // Variant styling & physical 3D extrusion shadows
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return {
          base: 'bg-gradient-to-b from-[#1A75FF] via-[#0066FF] to-[#004CC4] text-white border-t border-white/30',
          shadow: isPressed || reducedMotion
            ? '0 1px 0 #002e7a, 0 3px 8px rgba(0, 102, 255, 0.4)'
            : '0 5px 0 #002e7a, 0 10px 20px rgba(0, 102, 255, 0.45), 0 16px 30px rgba(0, 0, 0, 0.6)',
          transform: isPressed ? 'translateY(4px)' : 'translateY(0)',
          hoverShadow: 'hover:-translate-y-0.5 hover:shadow-[0_7px_0_#002e7a,0_14px_25px_rgba(0,102,255,0.55),0_20px_35px_rgba(0,0,0,0.7)]'
        };
      case 'cyan':
        return {
          base: 'bg-gradient-to-b from-[#38BDF8] via-[#00D2FF] to-[#0284C7] text-slate-950 font-black border-t border-white/50',
          shadow: isPressed || reducedMotion
            ? '0 1px 0 #0369a1, 0 3px 8px rgba(0, 210, 255, 0.5)'
            : '0 5px 0 #0369a1, 0 10px 20px rgba(0, 210, 255, 0.4), 0 16px 30px rgba(0, 0, 0, 0.6)',
          transform: isPressed ? 'translateY(4px)' : 'translateY(0)',
          hoverShadow: 'hover:-translate-y-0.5 hover:shadow-[0_7px_0_#0369a1,0_14px_25px_rgba(0,210,255,0.6)]'
        };
      case 'secondary':
        return {
          base: 'bg-gradient-to-b from-[#1E293B] to-[#0F172A] text-slate-100 border border-slate-700/60 border-t-white/20',
          shadow: isPressed || reducedMotion
            ? '0 1px 0 #060911, 0 3px 8px rgba(0, 0, 0, 0.4)'
            : '0 5px 0 #060911, 0 10px 20px rgba(0, 0, 0, 0.5)',
          transform: isPressed ? 'translateY(4px)' : 'translateY(0)',
          hoverShadow: 'hover:-translate-y-0.5 hover:border-blue-500/50 hover:shadow-[0_7px_0_#060911,0_14px_25px_rgba(0,102,255,0.25)]'
        };
      case 'glass':
        return {
          base: 'bg-slate-900/60 backdrop-blur-md text-white border border-blue-500/30 border-t-white/30',
          shadow: isPressed || reducedMotion
            ? '0 1px 0 rgba(0, 102, 255, 0.4), 0 3px 8px rgba(0, 0, 0, 0.4)'
            : '0 4px 0 rgba(0, 102, 255, 0.4), 0 8px 16px rgba(0, 102, 255, 0.25)',
          transform: isPressed ? 'translateY(3px)' : 'translateY(0)',
          hoverShadow: 'hover:-translate-y-0.5 hover:border-blue-400/60 hover:shadow-[0_6px_0_rgba(0,102,255,0.5),0_12px_22px_rgba(0,102,255,0.35)]'
        };
      case 'ghost':
      default:
        return {
          base: 'bg-transparent text-slate-300 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10',
          shadow: 'none',
          transform: 'none',
          hoverShadow: ''
        };
    }
  };

  const vStyle = getVariantStyles();

  return (
    <button
      id={id}
      onClick={onClick}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      onMouseLeave={() => setIsPressed(false)}
      style={{
        boxShadow: vStyle.shadow,
        transform: reducedMotion ? 'none' : vStyle.transform,
      }}
      className={`
        inline-flex items-center justify-center font-heading select-none cursor-pointer
        transition-all duration-150 ease-out active:scale-[0.98] outline-none focus-visible:ring-2 focus-visible:ring-blue-400
        ${sizeClasses}
        ${vStyle.base}
        ${!reducedMotion ? vStyle.hoverShadow : ''}
        ${glow ? 'ring-2 ring-blue-500/50 shadow-[0_0_25px_rgba(0,102,255,0.5)]' : ''}
        ${className}
      `.trim()}
      {...props}
    >
      {icon && iconPosition === 'left' && (
        <span className="inline-flex shrink-0 transition-transform group-hover:-translate-x-0.5">
          {icon}
        </span>
      )}
      <span className="tracking-wide relative z-10">{children}</span>
      {icon && iconPosition === 'right' && (
        <span className="inline-flex shrink-0 transition-transform group-hover:translate-x-1">
          {icon}
        </span>
      )}
    </button>
  );
};

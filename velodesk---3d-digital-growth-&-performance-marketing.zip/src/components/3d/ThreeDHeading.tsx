import React from 'react';
import { ThreeDText } from './ThreeDText';
import { ThreeDTextStyle, ThreeDDepth } from '../../types';

export interface ThreeDHeadingProps {
  level?: 1 | 2 | 3 | 4 | 5 | 6;
  text?: string;
  children?: React.ReactNode;
  styleVariant?: ThreeDTextStyle;
  depth?: ThreeDDepth;
  glow?: boolean;
  interactive?: boolean;
  className?: string;
  id?: string;
}

export const ThreeDHeading: React.FC<ThreeDHeadingProps> = ({
  level = 2,
  text,
  children,
  styleVariant,
  depth,
  glow = false,
  interactive = true,
  className = '',
  id,
}) => {
  const asTag = `h${level}` as 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

  // Default optimal styles per heading level
  const getDefaultVariant = (): ThreeDTextStyle => {
    if (styleVariant) return styleVariant;
    switch (level) {
      case 1:
        return 'extruded';
      case 2:
        return 'layered-perspective';
      case 3:
        return 'glass';
      case 4:
        return 'metallic';
      default:
        return 'soft-depth';
    }
  };

  const getDefaultDepth = (): ThreeDDepth => {
    if (depth) return depth;
    switch (level) {
      case 1:
        return 'extreme';
      case 2:
        return 'deep';
      case 3:
        return 'medium';
      default:
        return 'subtle';
    }
  };

  const getDefaultSize = (): string => {
    switch (level) {
      case 1:
        return 'text-4xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tight leading-[1.1]';
      case 2:
        return 'text-2xl sm:text-3xl md:text-4xl lg:text-5xl tracking-tight leading-[1.15]';
      case 3:
        return 'text-xl sm:text-2xl md:text-3xl tracking-normal leading-snug';
      case 4:
        return 'text-lg sm:text-xl md:text-2xl font-bold';
      case 5:
        return 'text-base sm:text-lg font-semibold';
      case 6:
        return 'text-sm sm:text-base font-semibold uppercase tracking-wider';
    }
  };

  return (
    <ThreeDText
      as={asTag}
      id={id}
      text={text}
      styleVariant={getDefaultVariant()}
      depth={getDefaultDepth()}
      size={getDefaultSize()}
      glow={glow}
      interactive={interactive}
      className={`font-heading ${className}`}
    >
      {children}
    </ThreeDText>
  );
};

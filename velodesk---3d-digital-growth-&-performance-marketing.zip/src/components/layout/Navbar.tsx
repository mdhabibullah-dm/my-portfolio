import React, { useState } from 'react';
import { useCms, PageRoute } from '../../context/CmsContext';
import { ThreeDLogo } from '../3d/ThreeDLogo';
import { ThreeDButton } from '../3d/ThreeDButton';
import { ThreeDText } from '../3d/ThreeDText';
import { 
  Menu, 
  X, 
  Settings, 
  Sparkles, 
  Sliders, 
  EyeOff, 
  Eye, 
  Database,
  ArrowUpRight 
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    currentRoute, 
    setCurrentRoute, 
    threeDQuality, 
    setThreeDQuality, 
    reducedMotion, 
    setReducedMotion 
  } = useCms();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const navItems: { label: string; route: PageRoute }[] = [
    { label: 'Services', route: 'services' },
    { label: 'Case Studies', route: 'casestudies' },
    { label: 'Portfolio', route: 'portfolio' },
    { label: 'Insights', route: 'blog' },
    { label: 'Free Audit', route: 'audit' },
  ];

  const handleNav = (route: PageRoute) => {
    setCurrentRoute(route);
    setMobileMenuOpen(false);
    setSettingsOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#070B14]/85 backdrop-blur-xl border-b border-slate-800/80 transition-all duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <ThreeDLogo 
          size="md" 
          interactive={true} 
          onClick={() => handleNav('home')} 
        />

        {/* Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-1.5 lg:gap-3">
          {navItems.map((item) => {
            const isActive = currentRoute === item.route;
            return (
              <button
                key={item.route}
                onClick={() => handleNav(item.route)}
                className={`
                  relative px-3.5 py-2 rounded-xl text-sm font-bold tracking-wide transition-all duration-150 cursor-pointer
                  ${isActive 
                    ? 'text-white bg-blue-600/20 border border-blue-500/40 shadow-[0_0_15px_rgba(0,102,255,0.25)]' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50 border border-transparent'}
                `}
              >
                <ThreeDText
                  as="span"
                  styleVariant={isActive ? 'glass' : 'soft-depth'}
                  depth="subtle"
                  interactive={false}
                  size="text-sm"
                  className={isActive ? 'font-extrabold' : 'font-semibold'}
                >
                  {item.label}
                </ThreeDText>
                {isActive && (
                  <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-4 h-0.5 rounded-full bg-[#00D2FF]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Action Group */}
        <div className="hidden md:flex items-center gap-3">
          {/* 3D Engine & Accessibility Settings Dropdown Toggle */}
          <div className="relative">
            <button
              onClick={() => setSettingsOpen(!settingsOpen)}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-700/60 text-slate-300 hover:text-blue-400 hover:border-blue-500/40 transition-colors cursor-pointer"
              title="3D Graphics & Accessibility Settings"
              aria-label="3D graphics controls"
            >
              <Sliders className="w-4 h-4" />
            </button>

            {settingsOpen && (
              <div className="absolute right-0 mt-3 w-72 rounded-2xl bg-[#0F172A] border border-blue-500/30 p-4 shadow-[0_20px_40px_rgba(0,0,0,0.8)] z-50">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
                  <span>3D Rendering Engine</span>
                  <Sparkles className="w-3.5 h-3.5 text-[#00D2FF]" />
                </div>

                {/* Quality Switcher */}
                <div className="mb-4">
                  <div className="text-xs text-slate-300 mb-1.5 font-medium">Quality Profile</div>
                  <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800">
                    {(['high', 'medium', 'low'] as const).map((q) => (
                      <button
                        key={q}
                        onClick={() => setThreeDQuality(q)}
                        className={`px-2 py-1.5 text-xs font-bold rounded-lg uppercase transition-all cursor-pointer ${
                          threeDQuality === q 
                            ? 'bg-blue-600 text-white shadow-[0_0_10px_rgba(0,102,255,0.4)]' 
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reduced Motion Toggle */}
                <div className="mb-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-slate-200">Reduced Motion</div>
                    <div className="text-[11px] text-slate-400">WCAG a11y compliance</div>
                  </div>
                  <button
                    onClick={() => setReducedMotion(!reducedMotion)}
                    className={`p-2 rounded-lg border cursor-pointer transition-colors ${
                      reducedMotion 
                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400' 
                        : 'bg-slate-900 border-slate-700 text-slate-400'
                    }`}
                  >
                    {reducedMotion ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Admin CMS Quick Link */}
                <div className="pt-3 border-t border-slate-800">
                  <button
                    onClick={() => handleNav('admin')}
                    className="w-full py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-blue-600/30 border border-slate-700 hover:border-blue-500/40 text-xs font-bold text-slate-200 hover:text-blue-300 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Database className="w-3.5 h-3.5" />
                    Open Admin CMS Dashboard
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Admin CMS Direct Shortcut */}
          <button
            onClick={() => handleNav('admin')}
            className={`px-3 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
              currentRoute === 'admin'
                ? 'bg-blue-600 text-white border-blue-400'
                : 'bg-slate-900 text-slate-300 hover:text-white border-slate-800 hover:border-slate-700'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-[#00D2FF]" />
            <span>Admin CMS</span>
          </button>

          {/* Primary 3D CTA Button */}
          <ThreeDButton
            id="nav-cta-audit"
            variant="cyan"
            size="sm"
            icon={<ArrowUpRight className="w-4 h-4" />}
            onClick={() => handleNav('audit')}
          >
            Get a Free Audit
          </ThreeDButton>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white cursor-pointer"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0A101D] border-b border-slate-800 px-6 py-6 space-y-4">
          <nav className="flex flex-col space-y-2">
            {navItems.map((item) => (
              <button
                key={item.route}
                onClick={() => handleNav(item.route)}
                className={`text-left px-4 py-3 rounded-xl font-bold text-base transition-colors ${
                  currentRoute === item.route
                    ? 'bg-blue-600/30 text-white border border-blue-500/40'
                    : 'text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => handleNav('admin')}
              className="text-left px-4 py-3 rounded-xl font-bold text-base text-slate-300 hover:bg-slate-800/60 flex items-center gap-2"
            >
              <Database className="w-4 h-4 text-[#00D2FF]" />
              Admin CMS Dashboard
            </button>
          </nav>

          <div className="pt-4 border-t border-slate-800/80 flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Reduced Motion:</span>
              <button
                onClick={() => setReducedMotion(!reducedMotion)}
                className="px-3 py-1 rounded bg-slate-800 text-white font-bold"
              >
                {reducedMotion ? 'ON' : 'OFF'}
              </button>
            </div>

            <ThreeDButton
              variant="cyan"
              size="md"
              className="w-full"
              icon={<ArrowUpRight className="w-4 h-4" />}
              onClick={() => handleNav('audit')}
            >
              Get a Free Audit
            </ThreeDButton>
          </div>
        </div>
      )}
    </header>
  );
};

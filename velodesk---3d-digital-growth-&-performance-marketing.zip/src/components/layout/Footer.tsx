import React, { useState } from 'react';
import { useCms } from '../../context/CmsContext';
import { ThreeDLogo } from '../3d/ThreeDLogo';
import { ThreeDText } from '../3d/ThreeDText';
import { ThreeDButton } from '../3d/ThreeDButton';
import { ArrowUpRight, CheckCircle2, ShieldCheck, Mail } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentRoute, services } = useCms();
  const [subscribed, setSubscribed] = useState(false);
  const [emailInput, setEmailInput] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    setSubscribed(true);
    setEmailInput('');
  };

  return (
    <footer className="relative bg-[#050810] border-t border-slate-800/80 pt-20 pb-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background radial glow */}
      <div 
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] pointer-events-none opacity-25"
        style={{
          background: 'radial-gradient(circle, rgba(0, 102, 255, 0.4) 0%, transparent 70%)',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Pre-Footer 3D Call To Action Banner */}
        <div className="mb-20 p-8 sm:p-12 md:p-16 rounded-3xl bg-gradient-to-r from-blue-950/80 via-slate-900 to-blue-950/80 border border-blue-500/30 text-center relative overflow-hidden shadow-[0_20px_50px_rgba(0,102,255,0.15)]">
          <div className="max-w-3xl mx-auto">
            <span className="inline-block px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-blue-500/20 text-[#00D2FF] mb-4">
              Next Step: Growth
            </span>
            <div className="mb-6">
              <ThreeDText
                as="h2"
                styleVariant="extruded"
                depth="deep"
                interactive={true}
                size="text-3xl sm:text-4xl md:text-5xl font-black"
                className="leading-tight text-white font-heading"
              >
                Turn Digital Attention Into Real Business Growth.
              </ThreeDText>
            </div>
            <p className="text-slate-300 text-base sm:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
              Stop guessing your return on ad spend. Partner with VeloDesk to engineer a predictable, 3D-accelerated customer acquisition engine.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <ThreeDButton
                variant="cyan"
                size="lg"
                icon={<ArrowUpRight className="w-5 h-5" />}
                onClick={() => setCurrentRoute('audit')}
              >
                Request Free 3D Audit
              </ThreeDButton>
              <ThreeDButton
                variant="secondary"
                size="lg"
                onClick={() => setCurrentRoute('services')}
              >
                View 10 Core Services
              </ThreeDButton>
            </div>
          </div>
        </div>

        {/* Footer Navigation Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 mb-16 pb-12 border-b border-slate-800">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <ThreeDLogo size="md" interactive={true} onClick={() => setCurrentRoute('home')} />
            <p className="text-sm text-slate-400 max-w-sm leading-relaxed mt-4">
              VeloDesk is an elite 3D performance marketing and digital engineering agency. We combine spatial web architecture with algorithmic media buying to turn digital attention into enterprise revenue.
            </p>
            <div className="pt-2 flex items-center gap-3 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>SOC2 Type II & HIPAA-compliant analytics pipelines</span>
            </div>
          </div>

          {/* Core Services */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-200 mb-4 font-heading">
              Growth Services
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-400">
              {services.slice(0, 6).map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => setCurrentRoute('services')}
                    className="hover:text-blue-400 transition-colors text-left cursor-pointer"
                  >
                    {s.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* More Services & Engineering */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-200 mb-4 font-heading">
              Engineering & Intel
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-400">
              {services.slice(6).map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => setCurrentRoute('services')}
                    className="hover:text-blue-400 transition-colors text-left cursor-pointer"
                  >
                    {s.title}
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() => setCurrentRoute('casestudies')}
                  className="hover:text-blue-400 transition-colors text-left cursor-pointer font-semibold text-blue-300"
                >
                  Verified Case Studies →
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter / Insights */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-200 mb-4 font-heading">
              Growth Newsletter
            </h4>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Bi-weekly teardowns of Generative SEO, CAPI tracking, and 3D CRO experiments.
            </p>
            {subscribed ? (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Subscribed! Check your inbox.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="relative">
                  <input
                    type="email"
                    required
                    placeholder="cmo@company.com"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <ThreeDButton type="submit" variant="primary" size="sm" className="w-full">
                  Subscribe
                </ThreeDButton>
              </form>
            )}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} VeloDesk Global Inc. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <button onClick={() => setCurrentRoute('admin')} className="hover:text-blue-400 transition-colors">
              Admin CMS
            </button>
            <button onClick={() => setCurrentRoute('audit')} className="hover:text-blue-400 transition-colors">
              Free Audit
            </button>
            <span>Terms of Service</span>
            <span>Privacy Policy</span>
            <span>Security</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
